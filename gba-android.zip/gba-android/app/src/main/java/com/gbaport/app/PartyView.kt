package com.gbaport.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** One party Pokémon as read from the game's RAM. */
class PartyMon(val species: Int, val level: Int, val hp: Int, val maxHp: Int, val status: Int, val egg: Boolean, val name: String)

/** Six-slot party strip: Gen III Pokémon sprites with only an HP bar beneath each sprite. */
class PartyView(ctx: Context) : View(ctx) {
    var party: List<PartyMon> = emptyList()
        set(v) { field = v; invalidate() }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cache = HashMap<Int, Bitmap>()
    private val loading = HashSet<Int>()
    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private val workers = Executors.newFixedThreadPool(2) { task ->
        Thread(task, "party-sprite-loader").apply { isDaemon = true }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val horizontal = width > height // portrait: six across; landscape: six down
        val gap = 3f * dp
        val pad = if (horizontal) 4f * dp else 3f * dp
        for (i in 0 until 6) {
            val r = if (horizontal) {
                val sw = (width - 2f * pad - 5f * gap) / 6f
                RectF(pad + i * (sw + gap), 2f * dp, pad + i * (sw + gap) + sw, height - 2f * dp)
            } else {
                val sh = (height - 2f * pad - 5f * gap) / 6f
                RectF(2f * dp, pad + i * (sh + gap), width - 2f * dp, pad + i * (sh + gap) + sh)
            }
            drawSlot(c, r, party.getOrNull(i), horizontal)
        }
    }

    private fun drawSlot(c: Canvas, r: RectF, mon: PartyMon?, portrait: Boolean) {
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = if (mon == null) 0x12FFFFFF else 0x20212635
        c.drawRoundRect(r, 7f * dp, 7f * dp, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f * dp
        paint.color = if (mon == null) 0x22FFFFFF else 0x3DFFFFFF
        c.drawRoundRect(RectF(r.left + .5f * dp, r.top + .5f * dp, r.right - .5f * dp, r.bottom - .5f * dp), 7f * dp, 7f * dp, paint)

        if (mon == null) return

        val barHeight = if (portrait) 4f * dp else 5f * dp
        val inset = if (portrait) 5f * dp else 8f * dp
        val spriteBottom = r.bottom - barHeight - 7f * dp
        val spriteTop = r.top + 2f * dp
        val spriteBox = RectF(r.left + 2f * dp, spriteTop, r.right - 2f * dp, spriteBottom)
        val bitmap = getSprite(mon.species)
        if (bitmap != null) {
            val scale = minOf(spriteBox.width() / bitmap.width, spriteBox.height() / bitmap.height)
            val bw = bitmap.width * scale
            val bh = bitmap.height * scale
            val dst = RectF(spriteBox.centerX() - bw / 2f, spriteBox.centerY() - bh / 2f,
                spriteBox.centerX() + bw / 2f, spriteBox.centerY() + bh / 2f)
            paint.style = Paint.Style.FILL
            paint.alpha = if (mon.hp <= 0 && !mon.egg) 125 else 255
            c.drawBitmap(bitmap, null, dst, paint)
            paint.alpha = 255
        }

        val barLeft = r.left + inset
        val barRight = r.right - inset
        val barTop = r.bottom - barHeight - 3f * dp
        val bar = RectF(barLeft, barTop, barRight, barTop + barHeight)
        paint.style = Paint.Style.FILL
        paint.color = 0xAA090B10.toInt()
        c.drawRoundRect(bar, barHeight / 2f, barHeight / 2f, paint)
        val ratio = if (mon.maxHp > 0) (mon.hp.toFloat() / mon.maxHp).coerceIn(0f, 1f) else 0f
        if (ratio > 0f) {
            paint.color = when {
                ratio > .5f -> 0xFF43D66B.toInt()
                ratio > .2f -> 0xFFF0C43B.toInt()
                else -> 0xFFED5147.toInt()
            }
            val fillRight = bar.left + bar.width() * ratio
            c.drawRoundRect(RectF(bar.left, bar.top, fillRight, bar.bottom), barHeight / 2f, barHeight / 2f, paint)
        }
    }

    /** Loads and caches the original Gen III Emerald front sprite for this National Dex species. */
    private fun getSprite(species: Int): Bitmap? {
        if (species !in 1..386) return null
        synchronized(lock) {
            cache[species]?.let { return it }
            if (!loading.add(species)) return null
        }
        workers.execute {
            var bitmap: Bitmap? = null
            try {
                val folder = File(context.cacheDir, "party_sprites").apply { mkdirs() }
                val file = File(folder, "$species.png")
                if (!file.exists() || file.length() == 0L) {
                    val url = URL("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/$species.png")
                    val connection = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 7000
                        readTimeout = 7000
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "GrLabs-GBA-Android")
                    }
                    try {
                        connection.connect()
                        if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                            connection.inputStream.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
                        }
                    } finally { connection.disconnect() }
                }
                if (file.exists() && file.length() > 0L) {
                    bitmap = BitmapFactory.decodeFile(file.absolutePath)
                    if (bitmap == null) file.delete()
                }
            } catch (_: Exception) { }
            synchronized(lock) {
                loading.remove(species)
                if (bitmap != null) cache[species] = bitmap!!
            }
            if (bitmap != null) main.post { invalidate() }
        }
        return null
    }
}
