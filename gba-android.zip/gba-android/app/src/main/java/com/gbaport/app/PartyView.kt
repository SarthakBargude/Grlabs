package com.gbaport.app

import android.content.Context
import android.graphics.*
import android.view.View

/** One party Pokémon as read from the game's RAM. */
class PartyMon(val species: Int, val level: Int, val hp: Int, val maxHp: Int, val status: Int, val egg: Boolean, val name: String)

/**
 * Party sidebar, PokeMMO style: six slots, each with a ball icon, name, level and an HP bar (green / yellow / red).
 * Landscape: a column down the left edge (the game picture moves right to make room).
 * Portrait: a row under the game display, when the screen has room for it.
 * Empty slots are drawn dim so all six are always visible.
 */
class PartyView(ctx: Context) : View(ctx) {
    var party: List<PartyMon> = emptyList()
        set(v) { field = v; invalidate() }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = Path()
    private val bounds = RectF()

    private fun rgba(r: Int, g: Int, b: Int, a: Float) = Color.argb((a * 255f).toInt().coerceIn(0, 255), r, g, b)

    private fun statusTag(s: Int): Pair<String, Int>? = when {
        s and 7 != 0 -> "SLP" to 0xFF8E9AAF.toInt()
        s and 0x88 != 0 -> "PSN" to 0xFFB46BDB.toInt()    // poison (bit 3) or toxic (bit 7)
        s and 0x10 != 0 -> "BRN" to 0xFFF08030.toInt()
        s and 0x20 != 0 -> "FRZ" to 0xFF70D0F0.toInt()
        s and 0x40 != 0 -> "PAR" to 0xFFF0C830.toInt()
        else -> null
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val horizontal = w > h
        val gap = 4f * dp
        val pad = if (horizontal) 4f * dp else 6f * dp
        val n = 6
        for (i in 0 until n) {
            val r = if (horizontal) {
                val sw = (w - 2 * pad - (n - 1) * gap) / n
                RectF(pad + i * (sw + gap), 0f, pad + i * (sw + gap) + sw, h)
            } else {
                val sh = (h - 2 * pad - (n - 1) * gap) / n
                RectF(pad, pad + i * (sh + gap), w - pad, pad + i * (sh + gap) + sh)
            }
            drawSlot(c, r, party.getOrNull(i), horizontal)
        }
    }

    private fun drawSlot(c: Canvas, r: RectF, m: PartyMon?, compact: Boolean) {
        val rad = 8f * dp
        paint.shader = null; paint.style = Paint.Style.FILL
        paint.color = if (m == null) rgba(255, 255, 255, 0.04f) else rgba(14, 14, 20, 0.82f)
        c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f * dp
        paint.color = if (m == null) rgba(255, 255, 255, 0.08f) else rgba(200, 205, 225, 0.30f)
        c.drawRoundRect(RectF(r.left + .5f * dp, r.top + .5f * dp, r.right - .5f * dp, r.bottom - .5f * dp), rad, rad, paint)

        val ix = 5f * dp
        val iconR = if (compact) 8f * dp else 10f * dp
        val icx = r.left + ix + iconR
        val icy = if (compact) r.top + 5f * dp + iconR else r.top + 5f * dp + iconR
        if (m == null) { drawBall(c, icx, icy, iconR, false, true); return }

        val fainted = m.hp <= 0 && !m.egg
        drawBall(c, icx, icy, iconR, fainted, false, m.egg)

        // name (+ level)
        val nameX = icx + iconR + 4f * dp
        val nameSize = if (compact) 8f * dp else 9.5f * dp
        text(c, if (m.egg) "EGG" else m.name.trim(), nameX, icy - (if (compact) 0f else 4f * dp), nameSize,
            if (fainted) 0xFF8A8A94.toInt() else 0xFFF0F1FA.toInt(), Paint.Align.LEFT, r.right - nameX - (if (compact) 20f else 3f) * dp)
        if (!compact && !m.egg) text(c, "Lv${m.level}", nameX, icy + 7f * dp, 8f * dp, 0xFFAEB2C4.toInt(), Paint.Align.LEFT, 0f)

        if (m.egg) return
        // HP bar
        val barH = 5f * dp
        val bl = r.left + 5f * dp; val br = r.right - 5f * dp
        val bt = if (compact) icy + iconR + 4f * dp else icy + iconR + 5f * dp
        val bar = RectF(bl, bt, br, bt + barH)
        paint.style = Paint.Style.FILL; paint.color = rgba(0, 0, 0, 0.65f)
        c.drawRoundRect(bar, barH / 2, barH / 2, paint)
        val f = if (m.maxHp > 0) (m.hp.toFloat() / m.maxHp).coerceIn(0f, 1f) else 0f
        if (f > 0f) {
            paint.color = when { f > 0.5f -> 0xFF4CD964.toInt(); f > 0.2f -> 0xFFF2C230.toInt(); else -> 0xFFEB4B3B.toInt() }
            c.drawRoundRect(RectF(bar.left, bar.top, bar.left + maxOf(barH, bar.width() * f), bar.bottom), barH / 2, barH / 2, paint)
        }
        // HP numbers + status
        val ty = bar.bottom + (if (compact) 7f else 8f) * dp
        if (compact) {
            text(c, "${m.hp}/${m.maxHp}", r.centerX(), ty, 7f * dp, 0xFFAEB2C4.toInt(), Paint.Align.CENTER, 0f)
        } else {
            text(c, "${m.hp}/${m.maxHp}", bl, ty, 8f * dp, 0xFFAEB2C4.toInt(), Paint.Align.LEFT, 0f)
        }
        statusTag(m.status)?.let { (tag, col) ->
            val tw = 20f * dp; val th = 11f * dp
            val tr = if (compact) RectF(r.right - tw - 3f * dp, r.top + 4f * dp, r.right - 3f * dp, r.top + 4f * dp + th)
                     else RectF(br - tw, ty - th / 2f, br, ty + th / 2f)
            paint.style = Paint.Style.FILL; paint.color = col
            c.drawRoundRect(tr, 3f * dp, 3f * dp, paint)
            text(c, tag, tr.centerX(), tr.centerY(), 7f * dp, 0xFF101018.toInt(), Paint.Align.CENTER, 0f)
        }
        if (compact) text(c, "L${m.level}", r.right - 5f * dp, icy, 7.5f * dp, 0xFFAEB2C4.toInt(), Paint.Align.RIGHT, 0f)
    }

    private fun text(c: Canvas, s: String, x: Float, cy: Float, size: Float, color: Int, align: Paint.Align, maxW: Float) {
        paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color
        paint.textSize = size; paint.textAlign = align; paint.typeface = Typeface.DEFAULT_BOLD
        var t = s
        if (maxW > 0f) while (t.length > 1 && paint.measureText(t) > maxW) t = t.dropLast(1)
        val fm = paint.fontMetrics
        c.drawText(t, x, cy - (fm.ascent + fm.descent) / 2f, paint)
    }

    /** A Poké Ball (grey when fainted, an egg for eggs, a faint outline for an empty slot). */
    private fun drawBall(c: Canvas, cx: Float, cy: Float, r: Float, fainted: Boolean, empty: Boolean, egg: Boolean = false) {
        paint.shader = null
        if (egg) {
            paint.style = Paint.Style.FILL; paint.color = 0xFFF4EBD0.toInt()
            c.drawOval(RectF(cx - r * .78f, cy - r, cx + r * .78f, cy + r), paint)
            paint.color = 0xFF9BC59B.toInt(); c.drawCircle(cx - r * .2f, cy - r * .15f, r * .18f, paint); c.drawCircle(cx + r * .25f, cy + r * .3f, r * .15f, paint)
            return
        }
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        if (empty) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f * dp; paint.color = rgba(255, 255, 255, 0.16f)
            c.drawCircle(cx, cy, r - .6f * dp, paint)
            c.drawLine(cx - r, cy, cx + r, cy, paint)
            return
        }
        val top = if (fainted) 0xFF5A5C68.toInt() else 0xFFE5432F.toInt()
        val bot = if (fainted) 0xFF8A8C98.toInt() else 0xFFF4F4F6.toInt()
        c.save()
        tmp.reset(); tmp.addCircle(cx, cy, r, Path.Direction.CW); c.clipPath(tmp)
        paint.style = Paint.Style.FILL
        paint.color = top; c.drawRect(rect.left, rect.top, rect.right, cy, paint)
        paint.color = bot; c.drawRect(rect.left, cy, rect.right, rect.bottom, paint)
        paint.color = 0xFF16161C.toInt(); c.drawRect(rect.left, cy - r * .14f, rect.right, cy + r * .14f, paint)
        c.restore()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.4f * dp; paint.color = 0xFF16161C.toInt()
        c.drawCircle(cx, cy, r - .7f * dp, paint)
        paint.style = Paint.Style.FILL; paint.color = 0xFF16161C.toInt(); c.drawCircle(cx, cy, r * .34f, paint)
        paint.color = if (fainted) 0xFF9A9AA6.toInt() else 0xFFF4F4F6.toInt(); c.drawCircle(cx, cy, r * .2f, paint)
    }
}
