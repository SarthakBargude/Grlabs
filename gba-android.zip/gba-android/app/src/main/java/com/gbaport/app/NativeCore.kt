package com.gbaport.app

import android.view.Surface

/** JNI wrapper around libgbacore.so (mGBA + GLES2 + AAudio). */
class NativeCore {
    companion object { init { System.loadLibrary("gbacore") } }
    external fun nativeInit()
    external fun nativeShutdown()
    external fun nativeSurfaceCreated(surface: Surface)
    external fun nativeSurfaceDestroyed()
    external fun nativeLoadRom(path: String): Boolean
    /** Writes the live battery-backed save data to the supplied .sav path without unloading the game. */
    external fun nativeSaveBattery(path: String): Boolean
    /** Loads a battery save into the running core and resets the game to apply it. */
    external fun nativeLoadBattery(path: String): Boolean
    /** Closes the current ROM. */
    external fun nativeUnloadRom()
    /** Swaps two occupied party slots in the game's live SaveBlock1; false if unavailable/in battle. */
    external fun nativeSwapParty(from: Int, to: Int): Boolean
    external fun nativeSetKeys(mask: Int)
    external fun nativeSetSpeed(speed: Int)
    external fun nativeSetPaused(paused: Boolean)
    external fun nativeGetState(): ByteArray?
    external fun nativeLoadState(data: ByteArray): Boolean
    /** 240x160 ARGB pixels of the last rendered frame (for thumbnails), or null. */
    external fun nativeGetFrame(): IntArray?

    // ---- Map extend + zoom (ported from PokeDaisy's EXPAND / ZOOM) ----
    /** True when the loaded game is one the map extend knows (a Pokémon Gen 3 release, matched by ROM CRC32). */
    external fun nativeWideKnown(): Boolean
    /** "Extend map" on / off. Off draws the plain 240x160 frame like before. */
    external fun nativeSetExtend(on: Boolean)
    /** The game view's size in pixels, so the zoom steps are known before the first frame is drawn. */
    external fun nativeSetViewSize(w: Int, h: Int)
    /** Next zoom step, back to 1x after the last. Returns the step now in force. */
    external fun nativeZoomCycle(): Int
    /** One step out (dir > 0) or in (dir < 0), stopping at the ends. Returns the step now in force. */
    external fun nativeZoomStep(dir: Int): Int
    external fun nativeSetZoom(level: Int)
    external fun nativeGetZoom(): Int
    /** How much more of the map each zoom step shows than 1x: [1.0, 1.46, 2.2] on a phone held upright. */
    external fun nativeZoomFactors(): FloatArray
    /** Party sidebar: 9 ints per slot: species, level, hp, maxHp, status, egg, then the name (10 chars packed 4 per int). Empty = none. */
    external fun nativeGetParty(): IntArray
    /** The game's own 64x64 front sprite (ARGB) for an internal species index, read from the ROM; null when its tables aren't found. */
    external fun nativeGetMonSprite(species: Int): IntArray?
    /** Look-around: the right stick, -1..1 per axis (right / down positive). */
    external fun nativeSetLook(x: Float, y: Float)
}

/** mGBA key bit positions. */
object Gba {
    const val A = 0; const val B = 1; const val SELECT = 2; const val START = 3
    const val RIGHT = 4; const val LEFT = 5; const val UP = 6; const val DOWN = 7
    const val R = 8; const val L = 9
    fun bit(k: Int) = 1 shl k
}
