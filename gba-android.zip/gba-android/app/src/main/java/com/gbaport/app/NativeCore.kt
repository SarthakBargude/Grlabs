package com.gbaport.app

import android.view.Surface

/** JNI wrapper around libgbacore.so (mGBA + GLES2 + AAudio). */
class NativeCore {
    companion object { init { System.loadLibrary("gbacore") } }
    external fun nativeInit()
    external fun nativeShutdown()
    external fun nativeSurfaceCreated(surface: Surface)
    external fun nativeSurfaceDestroyed()
    external fun nativeLoadRom(path: String): Boolean
    external fun nativeSetKeys(mask: Int)
    external fun nativeSetSpeed(speed: Int)
    external fun nativeSetPaused(paused: Boolean)
    external fun nativeGetState(): ByteArray?
    external fun nativeLoadState(data: ByteArray): Boolean
    /** 240x160 ARGB pixels of the last rendered frame (for thumbnails), or null. */
    external fun nativeGetFrame(): IntArray?

    // ---- Map extend + zoom (ported from PokeDaisy's EXPAND / ZOOM) ----
    /** True when the loaded game is one the map extend knows (a Pokémon Gen 3 release, matched by ROM CRC32). */
    external fun nativeWideKnown(): Boolean
    /** "Extend map" on / off. Off draws the plain 240x160 frame like before. */
    external fun nativeSetExtend(on: Boolean)
    /** The game view's size in pixels, so the zoom steps are known before the first frame is drawn. */
    external fun nativeSetViewSize(w: Int, h: Int)
    /** Next zoom step, back to 1x after the last. Returns the step now in force. */
    external fun nativeZoomCycle(): Int
    /** One step out (dir > 0) or in (dir < 0), stopping at the ends. Returns the step now in force. */
    external fun nativeZoomStep(dir: Int): Int
    external fun nativeSetZoom(level: Int)
    external fun nativeGetZoom(): Int
    /** How much more of the map each zoom step shows than 1x: [1.0, 1.46, 2.2] on a phone held upright. */
    external fun nativeZoomFactors(): FloatArray
    /** Look-around: the right stick, -1..1 per axis (right / down positive). */
    external fun nativeSetLook(x: Float, y: Float)
}

/** mGBA key bit positions. */
object Gba {
    const val A = 0; const val B = 1; const val SELECT = 2; const val START = 3
    const val RIGHT = 4; const val LEFT = 5; const val UP = 6; const val DOWN = 7
    const val R = 8; const val L = 9
    fun bit(k: Int) = 1 shl k
}
