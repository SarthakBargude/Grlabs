package com.gbaport.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.*
import android.view.View.MeasureSpec
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import kotlin.math.abs

class MainActivity : Activity() {
    private val core = NativeCore()
    private lateinit var controls: ControlsView
    private lateinit var home: HomeView
    private lateinit var states: StatesView
    private lateinit var menu: MenuView
    private lateinit var party: PartyView
    private lateinit var gameLayout: GameLayout
    private var partyOn = true       // "Party bar" setting
    private var partyShown = false   // sidebar is visible while a ROM is running, even before the party is populated
    private val prefs by lazy { getSharedPreferences("gba", MODE_PRIVATE) }
    private val romDir by lazy { File(filesDir, "roms").apply { mkdirs() } }      // playable copies of scanned ROMs + .sav
    private val stateDir by lazy { File(filesDir, "states").apply { mkdirs() } }
    private var romName: String? = null          // ROM currently loaded in the core (null = none)
    private var touchMask = 0
    private var padMask = 0
    private var fastForward = false
    private var dialogOpen = false
    private var homeOpen = true
    private var statesOpen = false
    private var menuOpen = false
    private var statesMode = MODE_SAVE
    private var games: List<Game> = emptyList()
    private var scanning = false
    private var extendOn = true      // "Extend map": Pokémon Gen 3 games drawn past the GBA frame (ported from PokeDaisy)
    private var zoomLevel = 0        // the zoom step picked: 0 = 1x, then each step shows more of the map

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        extendOn = prefs.getBoolean("extend", true)
        partyOn = prefs.getBoolean("party", true)
        zoomLevel = prefs.getInt("zoom", 0)
        core.nativeSetExtend(extendOn)
        core.nativeSetZoom(zoomLevel)
        core.nativeInit()

        val surface = SurfaceView(this)
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) = core.nativeSurfaceCreated(h.surface)
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { core.nativeSetViewSize(w, hh); refreshZoomUi(); surface.postDelayed({ refreshZoomUi() }, 400) }
            override fun surfaceDestroyed(h: SurfaceHolder) = core.nativeSurfaceDestroyed()
        })
        controls = ControlsView(this, { m -> touchMask = m; sendKeys() }, { showMenu() }, { toggleFast() }, { zoom(0) },
            { if (inGame() && romName != null) toast(if (writeSlot("q")) "Quick saved" else "Save failed") },
            { if (inGame() && romName != null) quickLoad() })
        controls.showShoulders = prefs.getBoolean("showLR", true)
        controls.showStartSelect = prefs.getBoolean("showSS", true)
        controls.onLayout = { refreshZoomUi() }
        home = HomeView(this, { g -> play(g) }, { pickFolder() }, { g -> confirmClear(g) })

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        party = PartyView(this)
        party.onSwapSlots = { from, to ->
            if (core.nativeSwapParty(from, to)) updateParty() else toast("Party slots cannot be swapped right now")
        }
        gameLayout = GameLayout(this, surface, controls, party)
        root.addView(gameLayout, FrameLayout.LayoutParams(-1, -1))
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        states = StatesView(this, { closeStates() }, { key -> slotTapped(key) }, { key -> slotLongPressed(key) })
        states.visibility = View.GONE
        root.addView(states, FrameLayout.LayoutParams(-1, -1))
        menu = MenuView(this) { closeMenu(); resume() }
        root.addView(menu, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        hideBars()
        showHome()
    }

    // ---------- Home screen ----------
    private fun isRom(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".gba") || n.endsWith(".agb")
    }

    private fun safeName(n: String) = n.replace(Regex("[^A-Za-z0-9._ -]"), "_")

    private fun treeUri(): Uri? = prefs.getString("tree", null)?.let { Uri.parse(it) }

    /** ROMs already copied into app storage (used only until a folder has been chosen). */
    private fun localGames(): List<Game> =
        (romDir.listFiles() ?: emptyArray<File>())
            .filter { it.isFile && isRom(it.name) }
            .map { Game(it.name, it.length(), null) }

    private fun sortGames(list: List<Game>): List<Game> {
        val last = prefs.getString("rom", null)
        return list.distinctBy { it.name }.sortedWith(compareBy<Game>({ it.name != last }, { it.name.lowercase() }))
    }

    private fun thumbOf(name: String): Bitmap? =
        File(stateDir, "$name.q.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }

    private fun refreshHome() =
        home.refresh(games, prefs.getString("rom", null), romName != null, scanning, treeUri() != null) { thumbOf(it) }

    private fun showHome() {
        if (!homeOpen) quickSave()
        closeMenu()
        controls.release(); core.nativeSetPaused(true)
        homeOpen = true
        refreshHome()
        home.visibility = View.VISIBLE
        scanFolder()
    }

    private fun hideHome() { homeOpen = false; home.visibility = View.GONE }

    // ---------- Folder scan ----------
    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(i, REQ_FOLDER) } catch (e: Exception) { toast("No file picker available") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri: Uri? = data?.data
        if (res != RESULT_OK || uri == null) {
            if (req == REQ_EXPORT || req == REQ_IMPORT) resume()
            return
        }
        when (req) {
            REQ_FOLDER -> {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
                prefs.edit().putString("tree", uri.toString()).apply()
                games = emptyList()
                scanFolder()
            }
            REQ_EXPORT -> writeSaveTo(uri)
            REQ_IMPORT -> readSaveFrom(uri)
        }
    }

    // ---------- Battery save export / import (.sav) ----------
    private fun saveFile(name: String) = File(romDir, name.substringBeforeLast('.') + ".sav")

    /** Exports a snapshot of the live cartridge save without unloading or restarting the game. */
    private fun exportSave() {
        val n = romName ?: run { resume(); return }
        core.nativeSetPaused(true)
        val save = saveFile(n)
        if (!core.nativeSaveBattery(save.absolutePath) || !save.exists() || save.length() == 0L) {
            toast("No battery save data yet. Save in the game first.")
            resume(); return
        }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, save.name)
        }
        try { startActivityForResult(i, REQ_EXPORT) }
        catch (e: Exception) { toast("No file picker available"); resume() }
    }

    private fun writeSaveTo(uri: Uri) {
        val n = romName ?: return
        try {
            val save = saveFile(n)
            if (!core.nativeSaveBattery(save.absolutePath) || !save.exists() || save.length() == 0L)
                throw java.io.IOException("No battery save data")
            contentResolver.openOutputStream(uri, "wt")?.use { out -> save.inputStream().use { it.copyTo(out) } }
                ?: throw java.io.IOException("no output stream")
            toast("Save exported")
        } catch (e: Exception) { toast("Export failed: ${e.message ?: "write error"}") }
        finally { resume() }
    }

    private fun importSave() {
        if (romName == null) { resume(); return }
        core.nativeSetPaused(true)
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        try { startActivityForResult(i, REQ_IMPORT) }
        catch (e: Exception) { toast("No file picker available"); resume() }
    }

    private fun readSaveFrom(uri: Uri) {
        val n = romName ?: return
        val bytes: ByteArray = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("no stream")
        } catch (e: Exception) { toast("Could not read file"); resume(); return }
        val validSizes = setOf(0x200, 0x2000, 0x8000, 0x10000, 0x20000, 0x40000)
        if (bytes.size !in validSizes) { toast("Invalid GBA save size (${bytes.size} bytes)"); resume(); return }
        sheet("Replace current save?", prettyName(n), listOf(
            SheetItem("Replace and restart game", style = STYLE_DANGER) {
                val f = saveFile(n)
                val backup = File(f.parentFile, f.name + ".bak")
                val tmp = File(f.parentFile, f.name + ".importing")
                try {
                    if (f.exists()) f.copyTo(backup, overwrite = true)
                    tmp.writeBytes(bytes)
                    if (!tmp.renameTo(f)) {
                        tmp.copyTo(f, overwrite = true)
                        if (!tmp.delete()) throw java.io.IOException("Could not finish save replacement")
                    }
                    if (!core.nativeLoadBattery(f.absolutePath)) {
                        if (backup.exists()) {
                            backup.copyTo(f, overwrite = true)
                            core.nativeLoadBattery(f.absolutePath)
                        }
                        throw java.io.IOException("The emulator rejected this save for the loaded game")
                    }
                    toast("Save imported. Previous save backed up.")
                } catch (e: Exception) {
                    if (backup.exists()) backup.copyTo(f, overwrite = true)
                    toast("Import failed: ${e.message ?: "write error"}")
                } finally { resume() }
            },
            SheetItem("Cancel") { resume() }
        ))
    }

    private fun scanFolder() {
        val tree = treeUri()
        if (tree == null) { games = sortGames(localGames()); refreshHome(); return }
        scanning = true; refreshHome()
        Thread {
            val found: List<Game>? = try { scanTree(tree) } catch (e: Exception) { null }
            runOnUiThread {
                scanning = false
                if (found == null) toast("Could not read the folder") else games = sortGames(found)
                if (homeOpen) refreshHome()
            }
        }.start()
    }

    /** Walks the chosen folder (up to 4 levels deep) and collects every .gba / .agb file. */
    private fun scanTree(tree: Uri): List<Game> {
        val out = ArrayList<Game>()
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE)
        fun walk(docId: String, depth: Int) {
            val dirs = ArrayList<String>()
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            contentResolver.query(kids, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1)
                    if (id == null || name == null) continue
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                    else if (isRom(name)) out.add(Game(safeName(name), c.getLong(3), DocumentsContract.buildDocumentUriUsingTree(tree, id)))
                }
            }
            if (depth < 4) for (d in dirs) walk(d, depth + 1)
        }
        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return out
    }

    // ---------- Playing ----------
    private fun play(g: Game) {
        if (g.name == romName) { hideHome(); resume(); return }     // already running: just jump back in
        val dest = File(romDir, g.name)
        if (g.uri == null || (dest.exists() && g.size > 0 && dest.length() == g.size)) { loadRom(g.name); return }
        toast("Loading…")
        Thread {
            val tmp = File(romDir, g.name + ".part")
            try {
                contentResolver.openInputStream(g.uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw java.io.IOException("rename")
            } catch (e: Exception) {
                tmp.delete()
                runOnUiThread { toast("Could not read file") }
                return@Thread
            }
            runOnUiThread { loadRom(g.name) }
        }.start()
    }

    private fun confirmClear(g: Game) {
        sheet("Clear game data?", prettyName(g.name), listOf(
            SheetItem("Delete saves and states", style = STYLE_DANGER) { clearData(g.name) },
            SheetItem("Cancel") { }
        ))
    }

    /** Removes the local copy, battery save and all save states. The ROM in your folder is never touched. */
    private fun clearData(name: String) {
        File(romDir, name).delete()
        File(romDir, name.substringBeforeLast('.') + ".sav").delete()
        stateDir.listFiles()?.filter { it.name.startsWith("$name.") }?.forEach { it.delete() }
        if (name == romName) { romName = null; fastForward = false; controls.fastOn = false }
        if (prefs.getString("rom", null) == name) prefs.edit().remove("rom").apply()
        if (treeUri() == null) games = sortGames(localGames())
        refreshHome()
        toast("Cleared")
    }

    private fun loadRom(name: String) {
        if (core.nativeLoadRom(File(romDir, name).absolutePath)) {
            romName = name; prefs.edit().putString("rom", name).apply()
            fastForward = false; controls.fastOn = false; core.nativeSetSpeed(1)
            core.nativeSetExtend(extendOn); core.nativeSetZoom(zoomLevel)
            refreshZoomUi()
            hideHome()
            core.nativeSetPaused(false)
        } else {
            toast("Not a valid GBA ROM")
            if (homeOpen) refreshHome()
        }
    }

    // ---------- Dialog sheet (small confirmations only) ----------
    private fun sheet(title: String, subtitle: String?, items: List<SheetItem>, resumeOnCancel: Boolean = true) {
        dialogOpen = true
        val d = buildSheet(this, title, subtitle, items,
            onPick = { item -> dialogOpen = false; item.onClick() },
            onCancel = { dialogOpen = false; if (resumeOnCancel) resume() })
        d.show(); hideBars()
    }

    // ---------- In-game menu page ----------
    private fun showMenu() {
        if (dialogOpen || homeOpen || menuOpen || statesOpen) return
        controls.release(); core.nativeSetPaused(true)
        menuOpen = true
        // Pokémon Gen 3 games the map extend knows get its two rows: the setting and the zoom step.
        val extendItems = if (core.nativeWideKnown()) listOf(
            SheetItem("Extend map", if (extendOn) "ON" else "OFF") { toggleExtend(); closeMenu(); resume() },
            SheetItem("Zoom", controls.zoomLabel ?: "1×") { closeMenu(); zoom(0); resume() }
        ) else emptyList()
        menu.open(romName?.let { prettyName(it) }, listOf(
            SheetItem("Resume", style = STYLE_PRIMARY) { closeMenu(); resume() },
            SheetItem("Quick save") { closeMenu(); toast(if (writeSlot("q")) "Quick saved" else "Save failed"); resume() },
            SheetItem("Quick load") { closeMenu(); quickLoad(); resume() },
            SheetItem("Save state") { closeMenu(); openStates(MODE_SAVE) },
            SheetItem("Load state") { closeMenu(); openStates(MODE_LOAD) },
            SheetItem("Fast-forward", if (fastForward) "ON" else "OFF") { toggleFast(); closeMenu(); resume() }
        ) + extendItems + listOf(
            SheetItem("Party bar", if (partyOn) "ON" else "OFF") { toggleParty(); closeMenu(); resume() },
            SheetItem("L / R buttons", if (controls.showShoulders) "ON" else "OFF") { toggleKeys("shoulders"); closeMenu(); resume() },
            SheetItem("Select / Start", if (controls.showStartSelect) "ON" else "OFF") { toggleKeys("startsel"); closeMenu(); resume() },
            SheetItem("Export save") { closeMenu(); exportSave() },
            SheetItem("Import save") { closeMenu(); importSave() },
            SheetItem("Reset") { closeMenu(); romName?.let { n -> loadRom(n) }; resume() },
            SheetItem("Home") { closeMenu(); showHome() }
        ))
    }

    private fun closeMenu() {
        menuOpen = false
        menu.close()
    }

    private fun toggleFast() {
        fastForward = !fastForward
        core.nativeSetSpeed(if (fastForward) 4 else 1)
        controls.fastOn = fastForward
    }

    // ---------- Party sidebar ----------
    private val partyPoll = object : Runnable {
        override fun run() { updateParty(); window.decorView.postDelayed(this, 400) }
    }

    /** Shows / hides the on-screen L+R or SELECT+START keys (remembered). A hidden key can't be pressed by touch either. */
    private fun toggleKeys(which: String) {
        if (which == "shoulders") { controls.showShoulders = !controls.showShoulders; prefs.edit().putBoolean("showLR", controls.showShoulders).apply() }
        else { controls.showStartSelect = !controls.showStartSelect; prefs.edit().putBoolean("showSS", controls.showStartSelect).apply() }
    }

    private fun toggleParty() {
        partyOn = !partyOn
        prefs.edit().putBoolean("party", partyOn).apply()
        updateParty()
    }

    private fun readParty(): List<PartyMon> {
        if (romName == null) return emptyList()
        val a = core.nativeGetParty()
        return (0 until a.size / 9).map { i ->
            val o = i * 9
            val sb = StringBuilder()
            for (w in 0..2) for (j in 0..3) { val ch = (a[o + 6 + w] ushr (8 * j)) and 0xFF; if (w * 4 + j < 10 && ch != 0) sb.append(ch.toChar()) }
            PartyMon(a[o], a[o + 1], a[o + 2], a[o + 3], a[o + 4], a[o + 5] != 0, sb.toString())
        }
    }

    /** Keep all six party positions visible whenever a ROM is running, even if the party is empty. */
    private fun updateParty() {
        val show = partyOn && !homeOpen && romName != null
        val mons = if (show) readParty() else emptyList()
        party.party = mons
        if (show != partyShown) {
            partyShown = show
            Geo.sideDp = if (show) 92f else 0f
            party.visibility = if (show) View.VISIBLE else View.GONE
            gameLayout.requestLayout()
            controls.relayout()
            window.decorView.post { refreshZoomUi() }
        }
    }

    // ---------- Map extend + zoom ----------
    private fun toggleExtend() {
        extendOn = !extendOn
        prefs.edit().putBoolean("extend", extendOn).apply()
        core.nativeSetExtend(extendOn)
        refreshZoomUi()
    }

    /** dir 0 = next zoom step (back to 1x after the last), +1 = one step out (more map), -1 = one step in. */
    private fun zoom(dir: Int) {
        if (!inGame() || !core.nativeWideKnown() || !extendOn) return
        zoomLevel = if (dir == 0) core.nativeZoomCycle() else core.nativeZoomStep(dir)
        prefs.edit().putInt("zoom", zoomLevel).apply()
        refreshZoomUi()
    }

    private fun factorText(f: Float): String {
        val r = Math.round(f * 10f) / 10f
        return (if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()) + "×"
    }

    /** The zoom button shows the step now in force; it is hidden for games the map extend doesn't know. */
    private fun refreshZoomUi() {
        if (romName == null || !extendOn || !core.nativeWideKnown()) { controls.zoomLabel = null; controls.zoomLit = false; return }
        val factors = core.nativeZoomFactors()
        val lv = core.nativeGetZoom().coerceIn(0, maxOf(0, factors.size - 1))
        controls.zoomLabel = factorText(factors.getOrElse(lv) { 1f })
        controls.zoomLit = lv > 0
    }

    // ---------- Save states (Quick save + slots 0..7, each with a thumbnail) ----------
    private val slotKeys = (0..7).map { "s$it" }

    private fun stateFile(key: String) = File(stateDir, "${romName ?: "game"}.$key.ss")
    private fun thumbFile(key: String) = File(stateDir, "${romName ?: "game"}.$key.png")
    private fun slotTitle(key: String) = if (key == "q") "QUICK SAVE" else "SLOT ${key.substring(1)}"

    /** Writes state + screenshot for [key]. Returns false when nothing could be saved. */
    private fun writeSlot(key: String): Boolean {
        if (romName == null) return false
        val data = core.nativeGetState() ?: return false
        try {
            stateFile(key).writeBytes(data)
            core.nativeGetFrame()?.let { px ->
                val bmp = Bitmap.createBitmap(px, 240, 160, Bitmap.Config.ARGB_8888)
                thumbFile(key).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
            }
        } catch (e: Exception) { return false }
        return true
    }

    private fun quickSave() { if (romName != null) writeSlot("q") }

    private fun quickLoad() {
        val f = stateFile("q")
        if (!f.exists()) { toast("No quick save yet"); return }
        toast(if (core.nativeLoadState(f.readBytes())) "Quick loaded" else "Load failed")
    }

    /** Load grid also lists the quick save (it is also written automatically when you leave the game). */
    private fun slotInfos(includeQuick: Boolean): List<SlotInfo> =
        ((if (includeQuick) listOf("q") else emptyList()) + slotKeys).map { key ->
            val f = stateFile(key)
            if (f.exists()) {
                val bmp = thumbFile(key).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) }
                SlotInfo(key, slotTitle(key), f.lastModified(), bmp)
            } else SlotInfo(key, slotTitle(key), null, null)
        }

    private fun openStates(mode: Int) {
        if (romName == null) { toast("Load a game first"); resume(); return }
        statesMode = mode
        statesOpen = true
        states.setTitle(if (mode == MODE_SAVE) "SAVE STATE" else "LOAD STATE")
        states.refresh(slotInfos(mode == MODE_LOAD))
        states.visibility = View.VISIBLE
    }

    private fun closeStates() { statesOpen = false; states.visibility = View.GONE; resume() }

    private fun slotTapped(key: String) {
        if (statesMode == MODE_SAVE) {
            toast(if (writeSlot(key)) "Saved to ${slotTitle(key).lowercase()}" else "Save failed")
            states.refresh(slotInfos(false))
        } else {
            val f = stateFile(key)
            if (!f.exists()) { toast("Empty slot"); return }
            if (core.nativeLoadState(f.readBytes())) { toast("Loaded"); closeStates() } else toast("Load failed")
        }
    }

    private fun slotLongPressed(key: String) {
        val f = stateFile(key)
        if (!f.exists()) return
        sheet(slotTitle(key).lowercase().replaceFirstChar { it.uppercase() }, "Delete this save?", listOf(
            SheetItem("Delete", style = STYLE_DANGER) {
                f.delete(); thumbFile(key).delete(); states.refresh(slotInfos(statesMode == MODE_LOAD))
            },
            SheetItem("Cancel") { }
        ))
    }

    private fun resume() { if (!dialogOpen && !homeOpen && !statesOpen && !menuOpen) core.nativeSetPaused(false) }

    // ---------- Input ----------
    private fun sendKeys() = core.nativeSetKeys(touchMask or padMask)

    private fun mapKey(code: Int) = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Gba.UP; KeyEvent.KEYCODE_DPAD_DOWN -> Gba.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Gba.LEFT; KeyEvent.KEYCODE_DPAD_RIGHT -> Gba.RIGHT
        KeyEvent.KEYCODE_BUTTON_B -> Gba.A; KeyEvent.KEYCODE_BUTTON_A -> Gba.B   // Xbox-style layout
        KeyEvent.KEYCODE_BUTTON_L1 -> Gba.L; KeyEvent.KEYCODE_BUTTON_R1 -> Gba.R
        KeyEvent.KEYCODE_BUTTON_START -> Gba.START; KeyEvent.KEYCODE_BUTTON_SELECT -> Gba.SELECT
        else -> -1
    }

    private fun inGame() = !homeOpen && !menuOpen && !statesOpen

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_UP) { showMenu(); return true }
        val pad = e.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_DPAD) != 0
        if (pad && inGame() && e.keyCode == KeyEvent.KEYCODE_BUTTON_THUMBR) {   // R3: next zoom step
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) zoom(0)
            return true
        }
        val k = if (pad && inGame()) mapKey(e.keyCode) else -1
        if (k >= 0) {
            padMask = if (e.action == KeyEvent.ACTION_DOWN) padMask or Gba.bit(k) else padMask and Gba.bit(k).inv()
            sendKeys(); return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            // Right stick = look around the extended map (Z / RZ on most pads, RX / RY on some). Not consumed.
            var rx = e.getAxisValue(MotionEvent.AXIS_Z); var ry = e.getAxisValue(MotionEvent.AXIS_RZ)
            if (abs(rx) < 0.05f && abs(ry) < 0.05f) { rx = e.getAxisValue(MotionEvent.AXIS_RX); ry = e.getAxisValue(MotionEvent.AXIS_RY) }
            if (inGame()) core.nativeSetLook(rx, ry) else core.nativeSetLook(0f, 0f)
        }
        if (inGame() && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X); val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            var m = padMask and (Gba.bit(Gba.LEFT) or Gba.bit(Gba.RIGHT) or Gba.bit(Gba.UP) or Gba.bit(Gba.DOWN)).inv()
            if (x < -0.5f) m = m or Gba.bit(Gba.LEFT); if (x > 0.5f) m = m or Gba.bit(Gba.RIGHT)
            if (y < -0.5f) m = m or Gba.bit(Gba.UP); if (y > 0.5f) m = m or Gba.bit(Gba.DOWN)
            padMask = m; sendKeys(); return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    @Deprecated("Back opens the menu / leaves the home screen")
    override fun onBackPressed() {
        if (menuOpen) { closeMenu(); resume(); return }
        if (statesOpen) { closeStates(); return }
        if (homeOpen) {
            if (romName != null) { hideHome(); resume() } else finish()   // game in progress: back returns to it
        } else showMenu()
    }

    // ---------- Lifecycle ----------
    private fun hideBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) hideBars() }
    override fun onPause() { window.decorView.removeCallbacks(partyPoll); if (!homeOpen) quickSave(); controls.release(); core.nativeSetPaused(true); super.onPause() }
    override fun onResume() { super.onResume(); resume(); window.decorView.removeCallbacks(partyPoll); window.decorView.post(partyPoll) }
    override fun onDestroy() { core.nativeShutdown(); super.onDestroy() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private const val MODE_SAVE = 0; private const val MODE_LOAD = 1
        private const val REQ_FOLDER = 2; private const val REQ_EXPORT = 3; private const val REQ_IMPORT = 4
    }
}

/** Places the game picture exactly where the GrLabs HTML launcher puts it (see Geo); controls draw over everything. */
class GameLayout(ctx: android.content.Context, private val game: View, private val ui: View, private val party: View) : ViewGroup(ctx) {
    private val dp = ctx.resources.displayMetrics.density
    init { setBackgroundColor(Color.BLACK); addView(game); addView(party); addView(ui); party.visibility = View.GONE }
    private fun partyBox(w: Int, h: Int) = Geo.partyRect(w, h, dp, Geo.sideDp > 0f)
    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws); val h = MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        val g = Geo.gameRect(w, h, dp)
        game.measure(MeasureSpec.makeMeasureSpec(g.width().toInt(), MeasureSpec.EXACTLY),
                     MeasureSpec.makeMeasureSpec(g.height().toInt(), MeasureSpec.EXACTLY))
        val p = partyBox(w, h)
        if (p != null) party.measure(MeasureSpec.makeMeasureSpec(p.width().toInt(), MeasureSpec.EXACTLY),
                                     MeasureSpec.makeMeasureSpec(p.height().toInt(), MeasureSpec.EXACTLY))
        ui.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val g = Geo.gameRect(measuredWidth, measuredHeight, dp)
        game.layout(g.left.toInt(), g.top.toInt(), g.left.toInt() + game.measuredWidth, g.top.toInt() + game.measuredHeight)
        val p = partyBox(measuredWidth, measuredHeight)
        if (p != null) party.layout(p.left.toInt(), p.top.toInt(), p.left.toInt() + party.measuredWidth, p.top.toInt() + party.measuredHeight)
        else party.layout(0, 0, 0, 0)
        ui.layout(0, 0, measuredWidth, measuredHeight)
    }
}
