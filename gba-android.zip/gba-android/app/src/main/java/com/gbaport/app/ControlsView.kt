package com.gbaport.app

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.abs
import kotlin.math.sin

/** Where the game picture goes. Same placement as the GrLabs HTML launcher (all sizes in dp = CSS px). */
object Geo {
    /** Slim portrait display: almost edge-to-edge (~4dp side gap), exact 3:2 GBA ratio, top at 60dp. */
    fun displayBox(w: Int, dp: Float): RectF {
        val m = w * 0.012f
        val bw = w - 2f * m
        val top = 60f * dp
        return RectF(m, top, m + bw, top + bw * 2f / 3f)
    }
    fun gameRect(w: Int, h: Int, dp: Float): RectF {
        if (w >= h) return RectF(0f, 0f, w.toFloat(), h.toFloat())
        return displayBox(w, dp)
    }
}

/**
 * Gamepad drawn like the GrLabs HTML launcher: same positions, colors and D-pad press animation.
 * Portrait  = control deck card at the bottom, L/R tabs on its top edge, header with brand + buttons.
 * Landscape = translucent controls floating over the game.
 */
class ControlsView(
    ctx: Context,
    private val onKeys: (Int) -> Unit,
    private val onMenu: () -> Unit,
    private val onFast: () -> Unit,
    /** Map-extend zoom: 0 = next step (the button), +1 = one step out / more map, -1 = one step in (pinch). */
    private val onZoom: (Int) -> Unit = {}
) : View(ctx) {

    var fastOn = false
        set(v) { field = v; invalidate() }

    /** The zoom button's text ("1x", "1.5x" ...); null hides the button (a game the map extend doesn't know). */
    var zoomLabel: String? = null
        set(v) { if (field != v) { field = v; invalidate() } }
    /** The zoom button is lit while zoomed out past 1x. */
    var zoomLit = false
        set(v) { if (field != v) { field = v; invalidate() } }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = Path()
    private val crossPath = Path()                  // D-pad outline in the HTML's 124x124 SVG units

    private var mask = 0
    private var portrait = true

    private val deck = RectF()
    private val dC = PointF()
    private var span = 0f; private var k = 1f; private var uiScale = 1f
        private val aC = PointF(); private val bC = PointF(); private var btnR = 0f
        private var aR = 0f; private var bR = 0f   // A and B can have different sizes (landscape matches the reference screenshot)
    private val lRect = RectF(); private val rRect = RectF()
    private val startRect = RectF(); private val selRect = RectF()
    private val menuRect = RectF(); private val fastRect = RectF(); private val zoomRect = RectF()
    private var pinchBase = 0f   // distance between two fingers when a pinch began / last stepped the zoom; 0 = none

    init { buildCross() }

    private fun buildCross() {
        val p = crossPath
        p.reset()
        p.moveTo(44f, 0f); p.lineTo(80f, 0f); p.quadTo(83f, 0f, 83f, 3f)
        p.lineTo(83f, 38f); p.quadTo(83f, 41f, 86f, 41f)
        p.lineTo(121f, 41f); p.quadTo(124f, 41f, 124f, 44f)
        p.lineTo(124f, 80f); p.quadTo(124f, 83f, 121f, 83f)
        p.lineTo(86f, 83f); p.quadTo(83f, 83f, 83f, 86f)
        p.lineTo(83f, 121f); p.quadTo(83f, 124f, 80f, 124f)
        p.lineTo(44f, 124f); p.quadTo(41f, 124f, 41f, 121f)
        p.lineTo(41f, 86f); p.quadTo(41f, 83f, 38f, 83f)
        p.lineTo(3f, 83f); p.quadTo(0f, 83f, 0f, 80f)
        p.lineTo(0f, 44f); p.quadTo(0f, 41f, 3f, 41f)
        p.lineTo(38f, 41f); p.quadTo(41f, 41f, 41f, 38f)
        p.lineTo(41f, 3f); p.quadTo(41f, 0f, 44f, 0f)
        p.close()
    }

    // ------------------------------------------------------------ layout (numbers measured from the HTML, in dp)
    private fun box(l: Float, t: Float, w: Float, h: Float) = RectF(l * dp, t * dp, (l + w) * dp, (t + h) * dp)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val wd = w / dp; val hd = h / dp
        portrait = h > w
        if (portrait) layoutPortrait(wd, hd) else layoutLandscape(wd, hd)
    }

    private fun layoutPortrait(wd: Float, hd: Float) {
        val m = if (wd < 380f) 8f else 12f
        val deckH = if (wd < 380f) 254f else 250f
        val top = hd - m - deckH
        deck.set(m * dp, top * dp, (wd - m) * dp, (top + deckH) * dp)

        val dcx = 0.2645f * wd
        dC.set(dcx * dp, (top + 100f) * dp)
        span = 140.4f * dp; k = span / 124f
        uiScale = 1.254f * dp

        // A/B arranged exactly like landscape (A bigger, up/right; B smaller, down/left),
        // centred on the D-pad's centre line and as far from the right edge as the D-pad is from the left.
        val padHalf = 70.2f
        val aRd = 34f; val bRd = aRd * (0.148f / 0.174f)      // same A:B size ratio as landscape
        val dx = aRd * 2f * (0.2074f / 0.174f)                // B -> A horizontal centre distance
        val dy = aRd * 2f * (0.0454f / 0.174f)                // B lower than A
        aR = aRd * dp; bR = bRd * dp; btnR = aR
        val clusterH = aRd + dy + bRd
        val cyDp = top + 100f
        val aX = wd - (dcx - padHalf) - aRd
        val aY = cyDp - clusterH / 2f + aRd
        aC.set(aX * dp, aY * dp)
        bC.set((aX - dx) * dp, (aY + dy) * dp)

        // floating shoulder keys: 8dp clear of the card (not connected to it)
        lRect.set(box(dcx - 20f - 56f, top - 8f - 28f, 112f, 28f))
        rRect.set(box(wd - (dcx - 20f) - 56f, top - 8f - 28f, 112f, 28f))
        selRect.set(box(wd / 2f - 74f, top + 195f, 64f, 23f))
        startRect.set(box(wd / 2f + 10f, top + 195f, 64f, 23f))

        menuRect.set(box(wd - 14f - 40f, 14f, 40f, 40f))
        fastRect.set(box(wd - 14f - 40f - 8f - 40f, 14f, 40f, 40f))
        zoomRect.set(box(wd - 14f - 40f - 8f - 40f - 8f - 40f, 14f, 40f, 40f))
    }

    private fun layoutLandscape(wd: Float, hd: Float) {
        // Everything is a fraction of the screen height, so it scales on any phone.
        // D-pad: lower half of the screen, centred vertically inside that half (y = 75% of height).
        // Same gap from the left edge (D-pad) and from the right edge (A/B cluster).
        val edge = 0.10f * hd
        val cyDp = 0.75f * hd
        dC.set((edge + 134.1f / 2f) * dp, cyDp * dp)
        span = 134.1f * dp; k = span / 124f
        uiScale = 0.9f * dp

        // A/B size + arrangement measured from the reference screenshot (2408x1080):
        // A diameter 188px = 0.174h, B diameter 160px = 0.148h, A is right/up of B.
        val aRd = 0.174f * hd / 2f; val bRd = 0.148f * hd / 2f
        val dx = 0.2074f * hd            // B -> A, horizontal centre distance
        val dy = 0.0454f * hd            // B is lower than A by this much
        aR = aRd * dp; bR = bRd * dp; btnR = aR

        val clusterH = aRd + dy + bRd    // cluster bounding box height
        val aX = wd - edge - aRd         // A's right side is `edge` from the screen edge
        val aY = cyDp - clusterH / 2f + aRd   // cluster is centred on the D-pad's centre line
        aC.set(aX * dp, aY * dp)
        bC.set((aX - dx) * dp, (aY + dy) * dp)

        // L and R share one horizontal line, wide, stuck to the left / right edge columns
        // (L over the D-pad's left edge, R over A's right edge) with a generous gap above the controls.
        val tw = 108f; val th = 30f; val gap = 36f
        val padTop = cyDp - 134.1f / 2f; val abTop = aY - aRd
        val lrTop = minOf(padTop, abTop) - gap - th
        lRect.set(box(edge, lrTop, tw, th))
        rRect.set(box(wd - edge - tw, lrTop, tw, th))
        selRect.set(box(wd / 2f - 76f, hd - 8f - 25f, 68f, 25f))
        startRect.set(box(wd / 2f + 8f, hd - 8f - 25f, 68f, 25f))

        val right = wd - 0.03f * wd              // top-right corner is free now that R moved down
        menuRect.set(box(right - 40f, 5f, 40f, 40f))
        fastRect.set(box(right - 40f - 8f - 40f, 5f, 40f, 40f))
        zoomRect.set(box(right - 40f - 8f - 40f - 8f - 40f, 5f, 40f, 40f))
    }

    // ------------------------------------------------------------ touch
    private fun inflated(r: RectF, g: Float) = RectF(r.left - g, r.top - g, r.right + g, r.bottom + g)

    private fun hit(x: Float, y: Float): Int {
        var m = 0
        val half = span / 2f
        val dx = x - dC.x; val dy = y - dC.y; val d = hypot(dx, dy)
        if (d < half * 1.45f && d > half * 0.12f) {
            val nx = dx / d; val ny = dy / d
            if (nx > 0.38f) m = m or Gba.bit(Gba.RIGHT)
            if (nx < -0.38f) m = m or Gba.bit(Gba.LEFT)
            if (ny > 0.38f) m = m or Gba.bit(Gba.DOWN)
            if (ny < -0.38f) m = m or Gba.bit(Gba.UP)
        }
        if (hypot(x - aC.x, y - aC.y) < aR * 1.35f) m = m or Gba.bit(Gba.A)
        if (hypot(x - bC.x, y - bC.y) < bR * 1.35f) m = m or Gba.bit(Gba.B)
        val g = 8f * dp
        if (inflated(lRect, g).contains(x, y)) m = m or Gba.bit(Gba.L)
        if (inflated(rRect, g).contains(x, y)) m = m or Gba.bit(Gba.R)
        if (inflated(startRect, g).contains(x, y)) m = m or Gba.bit(Gba.START)
        if (inflated(selRect, g).contains(x, y)) m = m or Gba.bit(Gba.SELECT)
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            val x = e.getX(i); val y = e.getY(i)
            if (menuRect.contains(x, y)) { onMenu(); return true }
            if (fastRect.contains(x, y)) { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onFast(); return true }
            if (zoomLabel != null && zoomRect.contains(x, y)) { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onZoom(0); return true }
        }
        pinch(e, act)
        var m = 0
        if (act != MotionEvent.ACTION_UP && act != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                m = m or hit(e.getX(i), e.getY(i))
            }
        }
        if (m != mask) {
            if (m and mask.inv() != 0) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            mask = m; onKeys(m); invalidate()
        }
        return true
    }

    /** True where a finger touches no button, D-pad or header control. */
    private fun onEmpty(x: Float, y: Float) =
        hit(x, y) == 0 && !menuRect.contains(x, y) && !fastRect.contains(x, y) && !(zoomLabel != null && zoomRect.contains(x, y))

    /** Two fingers that both start on empty space and move apart / together step the map zoom in / out. Fingers on the
     * controls never count, so playing with both thumbs can't zoom by accident. */
    private fun pinch(e: MotionEvent, act: Int) {
        if (zoomLabel == null) { pinchBase = 0f; return }
        when (act) {
            MotionEvent.ACTION_POINTER_DOWN ->
                pinchBase = if (e.pointerCount == 2 && onEmpty(e.getX(0), e.getY(0)) && onEmpty(e.getX(1), e.getY(1)))
                    hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)) else 0f
            MotionEvent.ACTION_MOVE -> if (pinchBase > 0f && e.pointerCount == 2) {
                val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                val ratio = d / pinchBase
                if (ratio > 1.35f) { onZoom(-1); pinchBase = d }        // fingers apart: closer in
                else if (ratio < 0.74f) { onZoom(1); pinchBase = d }    // fingers together: more map
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pinchBase = 0f
        }
    }

    fun release() { pinchBase = 0f; if (mask != 0) { mask = 0; onKeys(0); invalidate() } }
    private fun on(key: Int) = mask and Gba.bit(key) != 0

    // ------------------------------------------------------------ drawing helpers
    private fun rgba(r: Int, g: Int, b: Int, a: Float) = Color.argb((a * 255f).toInt().coerceIn(0, 255), r, g, b)

    private fun dim(color: Int, f: Float) = Color.argb(
        Color.alpha(color),
        (Color.red(color) * f).toInt(), (Color.green(color) * f).toInt(), (Color.blue(color) * f).toInt())

    private fun fill(color: Int) { paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color }
    private fun stroke(color: Int, w: Float) {
        paint.shader = null; paint.style = Paint.Style.STROKE; paint.color = color; paint.strokeWidth = w
    }

    private fun text(c: Canvas, s: String, cx: Float, cy: Float, size: Float, color: Int,
                     ls: Float = 0f, align: Paint.Align = Paint.Align.CENTER) {
        paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color
        paint.textSize = size; paint.textAlign = align; paint.typeface = Typeface.DEFAULT_BOLD
        paint.letterSpacing = ls
        val fm = paint.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, paint)
        paint.letterSpacing = 0f
    }

    /** CSS-style linear-gradient(angle) over a rectangle. */
    private fun cssGradient(r: RectF, deg: Float, colors: IntArray, stops: FloatArray): LinearGradient {
        val a = Math.toRadians(deg.toDouble())
        val dx = sin(a).toFloat(); val dy = (-cos(a)).toFloat()
        val len = abs(r.width() * dx) + abs(r.height() * dy)
        val cx = r.centerX(); val cy = r.centerY()
        return LinearGradient(cx - dx * len / 2f, cy - dy * len / 2f, cx + dx * len / 2f, cy + dy * len / 2f,
            colors, stops, Shader.TileMode.CLAMP)
    }

    // ------------------------------------------------------------ draw
    override fun onDraw(c: Canvas) {
        if (portrait) { drawBackdrop(c); drawDisplayBorder(c); drawDeck(c); drawHeader(c) } else drawToolbarLandscape(c)
        drawTab(c, lRect, "L", on(Gba.L))
        drawTab(c, rRect, "R", on(Gba.R))
        drawDpad(c)
        drawKey(c, aC, "A", on(Gba.A), aR)
        drawKey(c, bC, "B", on(Gba.B), bR)
        drawPill(c, selRect, "SELECT", on(Gba.SELECT))
        drawPill(c, startRect, "START", on(Gba.START))
    }

    // HTML .scanlines-overlay: 3px rows (lower half darkened .45) + 6px RGB-ish column tint, over #070709.
    private var texShader: BitmapShader? = null
    private fun texture(): BitmapShader {
        texShader?.let { return it }
        val tw = (6f * dp).toInt().coerceAtLeast(2); val th = (3f * dp).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); val p = Paint()
        p.color = rgba(0, 0, 0, 0.45f); cv.drawRect(0f, th / 2f, tw.toFloat(), th.toFloat(), p)   // dark half of each 3px row
        p.shader = LinearGradient(0f, 0f, tw.toFloat(), 0f,
            intArrayOf(rgba(255, 0, 0, 0.02f), rgba(0, 255, 0, 0.01f), rgba(0, 255, 0, 0.02f)), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, tw.toFloat(), th.toFloat(), p)
        return BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT).also { texShader = it }
    }

    private fun drawBackdrop(c: Canvas) {
        val g = Geo.gameRect(width, height, dp)
        c.save()
        c.clipRect(g, Region.Op.DIFFERENCE)          // keep the game surface visible
        fill(0xFF070709.toInt()); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.style = Paint.Style.FILL; paint.shader = texture()
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null
        c.restore()
    }

    private fun drawDisplayBorder(c: Canvas) {
        val b = Geo.displayBox(width, dp)
        stroke(0xFF444444.toInt(), 1f * dp)
        c.drawRoundRect(b, 2f * dp, 2f * dp, paint)
    }

    private fun drawDeck(c: Canvas) {
        val rt = 8f * dp; val rb = 15f * dp
        tmp.reset()
        tmp.addRoundRect(deck, floatArrayOf(rt, rt, rt, rt, rb, rb, rb, rb), Path.Direction.CW)
        paint.style = Paint.Style.FILL
        paint.shader = cssGradient(deck, 160f,
            intArrayOf(0xFF17171D.toInt(), 0xFF0B0B0F.toInt(), 0xFF14141A.toInt()), floatArrayOf(0f, 0.52f, 1f))
        c.drawPath(tmp, paint)
        val ins = RectF(deck.left + dp, deck.top + dp, deck.right - dp, deck.bottom - dp)
        tmp.reset()
        tmp.addRoundRect(ins, floatArrayOf(rt, rt, rt, rt, rb, rb, rb, rb), Path.Direction.CW)
        stroke(0xFF454550.toInt(), 2f * dp)
        c.drawPath(tmp, paint)
    }

    private fun drawHeader(c: Canvas) = topButtons(c, false)

    private fun drawToolbarLandscape(c: Canvas) = topButtons(c, true)

    /** Fast-forward (») and menu (hamburger) as two rounded-square buttons. */
    private fun topButtons(c: Canvas, floating: Boolean) {
        val accent = 0xFF7AA2FF.toInt()
        val ink = if (floating) 0xFFF2F2F2.toInt() else 0xFFD6D6DE.toInt()
        val rad = 12f * dp
        val inset = 2f * dp
        val zl = zoomLabel
        for (which in 0..2) {
            if (which == 2 && zl == null) continue
            val r0 = when (which) { 0 -> fastRect; 1 -> menuRect; else -> zoomRect }
            val r = RectF(r0.left + inset, r0.top + inset, r0.right - inset, r0.bottom - inset)
            val lit = (which == 0 && fastOn) || (which == 2 && zoomLit)
            fill(if (lit) rgba(122, 162, 255, 0.20f) else if (floating) rgba(0, 0, 0, 0.38f) else rgba(255, 255, 255, 0.07f))
            c.drawRoundRect(r, rad, rad, paint)
            stroke(if (lit) rgba(122, 162, 255, 0.70f) else rgba(255, 255, 255, if (floating) 0.28f else 0.16f), 1f * dp)
            c.drawRoundRect(r, rad, rad, paint)
        }

        // zoom: the current step's factor ("1x", "1.5x"), lit while zoomed out
        if (zl != null) text(c, zl, zoomRect.centerX(), zoomRect.centerY(), 12f * dp, if (zoomLit) accent else ink)

        // » : two chevrons
        val fc = if (fastOn) accent else ink
        // Pixel-stepped » glyph, matching the HTML launcher rather than smooth SVG chevrons.
        fill(fc)
        val cx = fastRect.centerX(); val cy = fastRect.centerY()
        val unit = 2f * dp
        for (i in 0..1) {
            val x0 = cx - 7f * dp + i * 8f * dp
            for (row in 0..4) {
                val width = if (row <= 2) (row + 1) else (5 - row)
                val yy = cy + (row - 2) * unit
                for (col in 0 until width) {
                    val xx = x0 + col * unit
                    c.drawRect(xx, yy, xx + unit, yy + unit, paint)
                }
            }
        }

        // hamburger: three bars
        stroke(ink, 2.2f * dp)
        val w = 16f * dp; val gap = 5.5f * dp
        for (i in -1..1) {
            val y = menuRect.centerY() + i * gap
            c.drawLine(menuRect.centerX() - w / 2f, y, menuRect.centerX() + w / 2f, y, paint)
        }
        paint.strokeCap = Paint.Cap.BUTT; paint.strokeJoin = Paint.Join.MITER
    }

    // ---- L / R shoulder tabs
    private fun drawTab(c: Canvas, r0: RectF, label: String, pressed: Boolean) {
        val oy = if (pressed) 2f * dp else 0f
        val r = RectF(r0.left, r0.top + oy, r0.right, r0.bottom + oy)
        if (portrait) {
            // Floating key, same slate gradient as the D-pad; sinks 2dp on press like A/B.
            val rad = 10f * dp
            if (!pressed) { fill(0xFF08080B.toInt()); c.drawRoundRect(RectF(r.left, r.top + 2f * dp, r.right, r.bottom + 2f * dp), rad, rad, paint) }
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(r.left, r.top, r.right, r.bottom,
                intArrayOf(0xFF5A5C68.toInt(), 0xFF3A3C47.toInt(), 0xFF23242C.toInt()),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, rad, rad, paint)
            if (pressed) { fill(rgba(0, 0, 0, 0.30f)); c.drawRoundRect(r, rad, rad, paint) }
            stroke(rgba(200, 205, 225, 0.35f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            text(c, label, r.centerX(), r.centerY(), 12f * dp, 0xFFF0F1FA.toInt())
        } else {
            val n = c.saveLayerAlpha(r.left - 2f, r.top - 2f, r.right + 2f, r.bottom + 2f, 230)
            val rad = 9f * dp
            fill(rgba(255, 255, 255, if (pressed) 0.35f else 0.20f)); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.40f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            text(c, label, r.centerX(), r.centerY(), 10f * dp, rgba(255, 255, 255, 0.9f))
            c.restoreToCount(n)
        }
    }

    // ---- SELECT / START capsules
    private fun drawPill(c: Canvas, r0: RectF, label: String, pressed: Boolean) {
        val oy = if (pressed) 2f * dp else 0f
        val r = RectF(r0.left, r0.top + oy, r0.right, r0.bottom + oy)
        if (portrait) {
            val rad = 3f * dp
            if (!pressed) {
                val s = RectF(r.left, r.top + 3f * dp, r.right, r.bottom + 3f * dp)
                fill(0xFF08080B.toInt()); c.drawRoundRect(s, rad, rad, paint)
            }
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, rgba(75, 75, 86, 0.92f), rgba(37, 37, 45, 0.96f), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(150, 150, 170, 0.58f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.20f), 1f * dp)
            c.drawLine(r.left + rad, r.top + 1.5f * dp, r.right - rad, r.top + 1.5f * dp, paint)
            if (pressed) { fill(rgba(0, 0, 0, 0.30f)); c.drawRoundRect(r, rad, rad, paint) }
            text(c, label, r.centerX(), r.centerY(), 7f * dp, 0xFFE2E2EB.toInt(), 0.08f)
        } else {
            val n = c.saveLayerAlpha(r.left - 2f, r.top - 2f, r.right + 2f, r.bottom + 2f, 219)
            val rad = 8f * dp
            fill(rgba(255, 255, 255, if (pressed) 0.35f else 0.20f)); c.drawRoundRect(r, rad, rad, paint)
            stroke(rgba(255, 255, 255, 0.40f), 1f * dp); c.drawRoundRect(r, rad, rad, paint)
            text(c, label, r.centerX(), r.centerY(), 8f * dp, rgba(255, 255, 255, 0.9f))
            c.restoreToCount(n)
        }
    }

    // ---- round A / B keys: same slate gradient + rim as the D-pad, in portrait AND landscape
    private fun drawKey(c: Canvas, p: PointF, label: String, pressed: Boolean, rad: Float) {
        val oy = if (pressed) 2f * dp else 0f
        val cx = p.x; val cy = p.y + oy; val r = rad
        val pad = 8f * dp
        val n = c.saveLayerAlpha(cx - r - pad, cy - r - pad, cx + r + pad, cy + r + pad + 4f * dp,
            if (portrait) 235 else 158)                // landscape uses the D-pad's .62 opacity
        if (portrait && !pressed) {
            fill(rgba(0, 0, 0, 0.45f)); c.drawCircle(cx, cy + 3.5f * dp, r, paint)
            fill(0xFF08080B.toInt()); c.drawCircle(cx, cy + 2f * dp, r, paint)
        }
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r,
            intArrayOf(0xFF5A5C68.toInt(), 0xFF3A3C47.toInt(), 0xFF23242C.toInt()),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)
        if (pressed) { fill(rgba(0, 0, 0, 0.30f)); c.drawCircle(cx, cy, r, paint) }
        stroke(rgba(200, 205, 225, 0.35f), 1f * dp); c.drawCircle(cx, cy, r - 0.5f * dp, paint)
        text(c, label, cx, cy, r * 0.70f, 0xFFF0F1FA.toInt())
        c.restoreToCount(n)
    }

    // ---- D-pad, same as the HTML launcher: a STATIC dark backing sits behind the gray cross.
    // On press the cross AND all four arrows shift 2px together in the pressed direction, so the
    // arrows stay glued to the cross and the backing peeking out gives the 3D "clack" look.
    private fun drawDpad(c: Canvas) {
        val up = on(Gba.UP); val down = on(Gba.DOWN); val lf = on(Gba.LEFT); val rt = on(Gba.RIGHT)
        val half = span / 2f
        val left = dC.x - half; val top = dC.y - half

        var layer = -1
        if (!portrait) layer = c.saveLayerAlpha(left - 12f * dp, top - 12f * dp, left + span + 12f * dp, top + span + 12f * dp, 158)  // opacity .62

        // 1) static black backing (never moves), fill + 3-unit stroke in the same dark gradient
        c.save(); c.translate(left, top); c.scale(k, k)
        val bg = LinearGradient(0f, 0f, 124f, 124f,
            intArrayOf(0xFF3A3C46.toInt(), 0xFF252630.toInt(), 0xFF14151B.toInt()),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        paint.shader = bg; paint.style = Paint.Style.FILL; c.drawPath(crossPath, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.strokeJoin = Paint.Join.ROUND
        c.drawPath(crossPath, paint)
        paint.strokeJoin = Paint.Join.MITER
        c.restore()

        // 2) gray cross + arrows move together by the same offset
        val ox = ((if (rt) 2f else 0f) - (if (lf) 2f else 0f)) * dp
        val oy = ((if (down) 2f else 0f) - (if (up) 2f else 0f)) * dp
        c.save(); c.translate(ox, oy)

        c.save(); c.translate(left, top); c.scale(k, k)
        paint.shader = LinearGradient(0f, 0f, 124f, 124f,
            intArrayOf(0xFF5A5C68.toInt(), 0xFF3A3C47.toInt(), 0xFF23242C.toInt()),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        paint.style = Paint.Style.FILL; c.drawPath(crossPath, paint)
        stroke(rgba(200, 205, 225, 0.35f), 1f); c.drawPath(crossPath, paint)
        c.restore()

        val dist = span * 0.335f                                 // centre of each arm (arm spans 0..41 of 124)
        arrow(c, 0f, -1f, dist); arrow(c, 0f, 1f, dist)
        arrow(c, -1f, 0f, dist); arrow(c, 1f, 0f, dist)
        c.restore()

        if (layer >= 0) c.restoreToCount(layer)
    }

    private fun arrow(c: Canvas, dx: Float, dy: Float, dist: Float) {
        val cx = dC.x + dx * dist
        val cy = dC.y + dy * dist
        val w = 10f * uiScale; val h = 7f * uiScale
        val px = -dy; val py = dx
        tmp.reset()
        tmp.moveTo(cx + dx * h / 2f, cy + dy * h / 2f)
        tmp.lineTo(cx - dx * h / 2f + px * w / 2f, cy - dy * h / 2f + py * w / 2f)
        tmp.lineTo(cx - dx * h / 2f - px * w / 2f, cy - dy * h / 2f - py * w / 2f)
        tmp.close()
        c.save(); c.translate(0f, -1f * dp)
        fill(rgba(0, 0, 0, 0.6f)); c.drawPath(tmp, paint)        // drop-shadow(0 -1px 0 #000c)
        c.restore()
        fill(rgba(192, 192, 208, 0.75f)); c.drawPath(tmp, paint)
    }
}
