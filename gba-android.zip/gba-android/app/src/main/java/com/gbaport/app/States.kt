package com.gbaport.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Pixel font for the save-state screen. Drop a pixel TTF (e.g. Silkscreen) at app/src/main/assets/fonts/pixel.ttf
 * and it is used automatically; without it the screen falls back to bold monospace.
 */
object PixelFont {
    private var cached: Typeface? = null
    fun get(ctx: Context): Typeface {
        cached?.let { return it }
        val t = try { Typeface.createFromAsset(ctx.assets, "fonts/pixel.ttf") }
                catch (e: Exception) { Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
        cached = t
        return t
    }
}

/** One cell of the save-state grid. [time] == null means the slot is empty. */
class SlotInfo(val key: String, val title: String, val time: Long?, val thumb: Bitmap?)

/** Square button with notched (pixel) corners and a pixel-art glyph drawn from a text pattern. */
open class PixelIconButton(
    ctx: Context, private val pattern: List<String>,
    private val fill: Int, private val fillPressed: Int, private val border: Int, private val ink: Int,
    private val boxed: Boolean = true
) : View(ctx) {
    private val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
    init { isClickable = true }

    private fun notched(c: Canvas, l: Float, t: Float, r: Float, b: Float, cut: Float, color: Int) {
        p.color = color
        c.drawRect(l + cut, t, r - cut, b, p)
        c.drawRect(l, t + cut, r, b - cut, p)
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height.toFloat()
        val u = Math.round(3f * d).toFloat()                       // one "pixel" of the border/corner
        if (boxed) {
            notched(c, 0f, 0f, w, h, u, border)
            notched(c, u / 1.5f, u / 1.5f, w - u / 1.5f, h - u / 1.5f, u / 1.5f, if (isPressed) fillPressed else fill)
        }
        val n = pattern.size; val m = pattern[0].length
        val px = Math.max(1, Math.round(Math.min(w, h) * (if (boxed) 0.46f else 0.78f) / Math.max(n, m)))
        val ox = ((w - m * px) / 2f).toInt().toFloat(); val oy = ((h - n * px) / 2f).toInt().toFloat()
        p.color = if (!boxed && isPressed) fillPressed else ink
        for (y in 0 until n) for (x in 0 until m)
            if (pattern[y][x] == 'X') c.drawRect(ox + x * px, oy + y * px, ox + (x + 1) * px, oy + (y + 1) * px, p)
    }
}

/** White capsule with "Close" text (no border). */
internal fun closeButton(ctx: Context): TextView = TextView(ctx).apply {
    text = "Close"; textSize = 12f; setTextColor(0xFF0B0B0F.toInt())
    typeface = PixelFont.get(ctx); letterSpacing = 0.1f; includeFontPadding = false
    gravity = Gravity.CENTER
    setPadding(ctx.dpi(18f), 0, ctx.dpi(18f), 0)
    val r = ctx.dpi(17f).toFloat()
    background = pressable(shape(Color.WHITE, r), shape(0xFFC9C9D1.toInt(), r))
    isClickable = true
}

/** Full-screen "SAVE STATES" grid: Quick Save (auto) + numbered slots with screenshot thumbnails. */
class StatesView(
    ctx: Context,
    private val onClose: () -> Unit,
    private val onSlot: (String) -> Unit,
    private val onSlotLong: (String) -> Unit
) : FrameLayout(ctx) {

    private val titleView = TextView(ctx)

    private val header = FrameLayout(ctx)
    private val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var slots: List<SlotInfo> = emptyList()
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0

    init {
        setBackgroundColor(0xFF08080B.toInt())
        isClickable = true

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        header.addView(titleView.apply {
            text = "SAVE STATE"; textSize = 15f; setTextColor(Color.WHITE)
            typeface = PixelFont.get(ctx); letterSpacing = 0.25f; includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.START))
        header.addView(closeButton(ctx).apply { setOnClickListener { onClose() } },
            LayoutParams(LayoutParams.WRAP_CONTENT, ctx.dpi(34f), Gravity.CENTER_VERTICAL or Gravity.END))
        col.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(View(ctx).apply { setBackgroundColor(0xFF22222A.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))

        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(grid) }
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding(); rebuild()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        val p = context.dpi(18f)
        header.setPadding(p + insL, context.dpi(14f) + insT, p + insR, context.dpi(14f))
        grid.setPadding(p + insL, p, p + insR, p + insB)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { rebuild() }
    }

    fun setTitle(t: String) { titleView.text = t }

    fun refresh(list: List<SlotInfo>) { slots = list; rebuild() }

    private fun rebuild() {
        val c = context
        val avail = width - grid.paddingLeft - grid.paddingRight
        fillGrid(c, grid, avail, slots.size) { idx, cardW ->
            val s = slots[idx]
            val stamp = s.time?.let { java.text.SimpleDateFormat("dd/MM/yyyy, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(it)) }
            val caption = if (stamp != null) "${s.title} · $stamp" else s.title
            previewCard(c, s.thumb, "EMPTY", caption, stamp == null, cardW,
                { onSlot(s.key) }, { onSlotLong(s.key) })
        }
    }
}

/** Lays [n] cards out in rows of equal-width columns. [make] gets (index, cardWidthPx). */
fun fillGrid(c: Context, grid: LinearLayout, avail: Int, n: Int, make: (Int, Int) -> View) {
    grid.removeAllViews()
    if (avail <= 0 || n == 0) return
    val gap = c.dpi(12f)
    val cols = maxOf(2, avail / c.dpi(210f))
    val cardW = (avail - gap * (cols - 1)) / cols
    var i = 0
    while (i < n) {
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for (j in 0 until cols) {
            val lp = LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (j > 0) lp.leftMargin = gap
            if (i + j < n) row.addView(make(i + j, cardW), lp)
            else row.addView(View(c), LinearLayout.LayoutParams(cardW, 1).apply { if (j > 0) leftMargin = gap })
        }
        grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { if (i > 0) topMargin = gap })
        i += cols
    }
}

/** The screenshot card used by the save/load grid AND the home screen. */
fun previewCard(c: Context, thumb: Bitmap?, emptyText: String, caption: String, dimCaption: Boolean,
                cardW: Int, onClick: () -> Unit, onLong: (() -> Unit)?): View {
    val pad = c.dpi(10f)
    val r = c.dpi(18f).toFloat()
    val card = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad, pad, pad)
        background = pressable(shape(0xFF111116.toInt(), r, 0xFF2A2A33.toInt(), c.dpi(1f)),
                               shape(0xFF1A1A22.toInt(), r, 0xFF3A3A46.toInt(), c.dpi(1f)))
        isClickable = true
        setOnClickListener { onClick() }
        if (onLong != null) setOnLongClickListener { onLong(); true }
    }
    val tw = cardW - pad * 2
    val th = tw * 2 / 3
    val radius = c.dpi(12f).toFloat()
    val thumbBox = FrameLayout(c).apply {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, radius) }
        }
        setBackgroundColor(0xFF050507.toInt())
    }
    if (thumb != null) {
        val d = BitmapDrawable(c.resources, thumb); d.setFilterBitmap(false)
        thumbBox.addView(ImageView(c).apply { setImageDrawable(d); scaleType = ImageView.ScaleType.FIT_XY },
            FrameLayout.LayoutParams(-1, -1))
    } else {
        thumbBox.addView(TextView(c).apply {
            text = emptyText; textSize = 11f; setTextColor(0xFF3A3A44.toInt())
            typeface = PixelFont.get(c); letterSpacing = 0.18f; includeFontPadding = false
        }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
    }
    card.addView(thumbBox, LinearLayout.LayoutParams(tw, th))
    card.addView(TextView(c).apply {
        text = caption; textSize = 10.5f; typeface = PixelFont.get(c); letterSpacing = 0.12f
        setTextColor(if (dimCaption) 0xFF55555F.toInt() else 0xFFEDEDF3.toInt())
        minLines = 2; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; includeFontPadding = false
        setLineSpacing(c.dpi(3f).toFloat(), 1f)
    }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = c.dpi(10f) })
    return card
}
