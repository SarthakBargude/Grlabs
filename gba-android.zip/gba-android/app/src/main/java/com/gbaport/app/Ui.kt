package com.gbaport.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/** Colours shared by the menu and the home screen (same palette as the GrLabs launcher). */
object Ui {
    val ACCENT = 0xFF7AA2FF.toInt()
    val ACCENT_HI = 0xFF9DB8FF.toInt()
    val CARD = 0xFF14141A.toInt()
    val CARD_HI = 0xFF1D1D26.toInt()
    val BORDER = 0xFF2E2E38.toInt()
    val TEXT = 0xFFF2F2F7.toInt()
    val MUTED = 0xFF9A9AA8.toInt()
    val DANGER = 0xFFFF6B6B.toInt()
    val BADGES = intArrayOf(
        0xFF7AA2FF.toInt(), 0xFF6EE7B7.toInt(), 0xFFF9A8D4.toInt(),
        0xFFFCD34D.toInt(), 0xFFC4B5FD.toInt(), 0xFFFDBA74.toInt())
}

fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun shape(color: Int, radius: Float, strokeColor: Int = 0, strokeWidth: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable = StateListDrawable().apply {
    addState(intArrayOf(android.R.attr.state_pressed), pressed)
    addState(intArrayOf(), normal)
}

fun label(ctx: Context, text: String, sp: Float, color: Int, bold: Boolean = false, spacing: Float = 0f): TextView =
    TextView(ctx).apply {
        this.text = text; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        letterSpacing = spacing
        includeFontPadding = false
    }

fun prettyName(file: String): String = file.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { file }

// =====================================================================================================
// Menu sheet
// =====================================================================================================

const val STYLE_NORMAL = 0
const val STYLE_PRIMARY = 1
const val STYLE_DANGER = 2

class SheetItem(val label: String, val detail: String? = null, val style: Int = STYLE_NORMAL, val onClick: () -> Unit)

/** Dark rounded card with a title and a list of tappable rows. Back / tapping outside calls [onCancel]. */
fun buildSheet(a: Activity, title: String, subtitle: String?, items: List<SheetItem>,
               onPick: (SheetItem) -> Unit, onCancel: () -> Unit): Dialog {
    val d = Dialog(a)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)

    val card = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Ui.CARD, a.dpi(22f).toFloat(), Ui.BORDER, a.dpi(1f))
        setPadding(a.dpi(10f), a.dpi(20f), a.dpi(10f), a.dpi(10f))
    }
    card.addView(label(a, title, 20f, Ui.TEXT, true).apply { setPadding(a.dpi(12f), 0, a.dpi(12f), 0) })
    if (subtitle != null) {
        card.addView(label(a, subtitle, 12.5f, Ui.MUTED).apply {
            setPadding(a.dpi(12f), a.dpi(6f), a.dpi(12f), 0)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
    }

    val list = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, a.dpi(14f), 0, 0)
    }
    for (item in items) list.addView(sheetRow(a, item) { d.dismiss(); onPick(item) })
    val scroll = ScrollView(a).apply { isVerticalScrollBarEnabled = false; addView(list) }
    card.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    d.setContentView(card)
    d.setOnCancelListener { onCancel() }
    d.window?.apply {
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        setDimAmount(0.7f)
        val w = minOf(a.resources.displayMetrics.widthPixels - a.dpi(32f), a.dpi(360f))
        setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    return d
}

fun sheetRow(a: Context, item: SheetItem, click: () -> Unit): View {
    val r = a.dpi(14f).toFloat()
    val primary = item.style == STYLE_PRIMARY
    val textColor = when (item.style) { STYLE_PRIMARY -> 0xFF0B0B0F.toInt(); STYLE_DANGER -> Ui.DANGER; else -> Ui.TEXT }
    val normal = shape(if (primary) Ui.ACCENT else Color.TRANSPARENT, r)
    val pressed = shape(if (primary) Ui.ACCENT_HI else 0x22FFFFFF, r)

    return LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(a.dpi(14f), 0, a.dpi(14f), 0)
        background = pressable(normal, pressed)
        isClickable = true
        setOnClickListener { click() }
        addView(label(a, item.label, 16f, textColor, primary || item.style == STYLE_DANGER),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        item.detail?.let { det ->
            addView(label(a, det, 13f, if (det == "ON") Ui.ACCENT else Ui.MUTED, true))
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dpi(52f)).apply {
            bottomMargin = a.dpi(4f)
        }
    }
}

// =====================================================================================================
// Right-hand drawer menu
// =====================================================================================================

/** In-game menu: a panel that slides in from the right edge over a dimmed scrim. */
class DrawerView(ctx: Context, private val onDismiss: () -> Unit) : FrameLayout(ctx) {
    private val scrim = View(ctx).apply { setBackgroundColor(0xB3000000.toInt()); alpha = 0f; setOnClickListener { onDismiss() } }
    private val panelW = minOf(ctx.dpi(300f), ctx.resources.displayMetrics.widthPixels - ctx.dpi(48f))
    private val panel = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        val r = ctx.dpi(24f).toFloat()
        background = GradientDrawable().apply {
            setColor(Ui.CARD); setStroke(ctx.dpi(1f), Ui.BORDER)
            cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        }
        isClickable = true
    }
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var insT = 0; private var insR = 0; private var insB = 0
    val isOpen get() = visibility == VISIBLE

    init {
        visibility = GONE
        isClickable = true
        addView(scrim, LayoutParams(-1, -1))
        addView(panel, LayoutParams(panelW, LayoutParams.MATCH_PARENT, Gravity.END))
        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        panel.setPadding(context.dpi(14f), context.dpi(22f) + insT, context.dpi(10f) + insR, context.dpi(12f) + insB)
    }

    fun open(title: String, subtitle: String?, items: List<SheetItem>) {
        val c = context
        panel.removeAllViews(); list.removeAllViews()
        panel.addView(label(c, title, 20f, Ui.TEXT, true).apply { setPadding(c.dpi(8f), 0, c.dpi(8f), 0) })
        if (subtitle != null) {
            panel.addView(label(c, subtitle, 12.5f, Ui.MUTED).apply {
                setPadding(c.dpi(8f), c.dpi(6f), c.dpi(8f), 0); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            })
        }
        for (item in items) list.addView(sheetRow(c, item) { item.onClick() })
        val sv = ScrollView(c).apply { isVerticalScrollBarEnabled = false; addView(list) }
        panel.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = c.dpi(14f) })

        panel.animate().cancel(); scrim.animate().cancel()
        visibility = VISIBLE
        panel.translationX = panelW.toFloat(); scrim.alpha = 0f
        panel.animate().translationX(0f).setDuration(220).start()
        scrim.animate().alpha(1f).setDuration(220).start()
    }

    fun close(animate: Boolean) {
        panel.animate().cancel(); scrim.animate().cancel()
        if (!animate || visibility != VISIBLE) { visibility = GONE; return }
        scrim.animate().alpha(0f).setDuration(180).start()
        panel.animate().translationX(panelW.toFloat()).setDuration(180).withEndAction { visibility = GONE }.start()
    }
}

// =====================================================================================================
// Home screen
// =====================================================================================================

/** A ROM found in the library folder. [uri] is null for a ROM already copied into app storage. */
class Game(val name: String, val size: Long, val uri: Uri?)

/** Full-screen home: header with folder button, then the games as screenshot cards (same look as save states). */
class HomeView(
    ctx: Context,
    private val onPlay: (Game) -> Unit,
    private val onFolder: () -> Unit,
    private val onLong: (Game) -> Unit
) : FrameLayout(ctx) {

    private val content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0
    private var games: List<Game> = emptyList()
    private var lastName: String? = null
    private var running = false
    private var scanning = false
    private var hasFolder = false
    private var thumbFor: (String) -> Bitmap? = { null }

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; isFillViewport = true }
        sv.addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(sv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding(); rebuild()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        val p = context.dpi(18f)
        content.setPadding(p + insL, context.dpi(18f) + insT, p + insR, context.dpi(28f) + insB)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { rebuild() }
    }

    fun refresh(games: List<Game>, lastName: String?, running: Boolean, scanning: Boolean,
                hasFolder: Boolean, thumbFor: (String) -> Bitmap?) {
        this.games = games; this.lastName = lastName; this.running = running
        this.scanning = scanning; this.hasFolder = hasFolder; this.thumbFor = thumbFor
        rebuild()
    }

    private fun rebuild() {
        val c = context
        content.removeAllViews()

        val header = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(c).apply {
            setImageResource(R.drawable.grlabs_logo); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(22f)))
        header.addView(label(c, "GrLabs", 13f, Color.WHITE, true, 0.14f).apply { setPadding(c.dpi(8f), 0, 0, 0) })
        header.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(pillButton(c, if (hasFolder) "Change folder" else "Choose folder", 13f, 38f) { onFolder() })
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(label(c, "Games", 32f, Ui.TEXT, true), topMargin(c, 26f))
        val sub = when {
            scanning && games.isEmpty() -> "Scanning folder…"
            games.isEmpty() && !hasFolder -> "Pick the folder that holds your ROMs"
            games.isEmpty() -> "No .gba files found in that folder"
            else -> "${games.size} found" + if (scanning) " · scanning…" else ""
        }
        content.addView(label(c, sub, 14f, Ui.MUTED), topMargin(c, 6f))

        if (games.isEmpty()) { if (!scanning) emptyState(c); return }

        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        content.addView(box, topMargin(c, 22f))
        val avail = width - content.paddingLeft - content.paddingRight
        fillGrid(c, box, avail, games.size) { i, cardW ->
            val g = games[i]
            val playing = running && g.name == lastName
            val caption = prettyName(g.name) + if (playing) "\nPLAYING" else ""
            previewCard(c, thumbFor(g.name), "NO PREVIEW", caption, false, cardW, { onPlay(g) }, { onLong(g) })
        }
        content.addView(label(c, "Long-press a game to clear its saves", 12f, Ui.MUTED).apply { gravity = Gravity.CENTER },
            topMargin(c, 18f))
    }

    private fun topMargin(c: Context, dp: Float) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = c.dpi(dp) }

    private fun pillButton(c: Context, text: String, sp: Float, heightDp: Float, click: () -> Unit): View =
        TextView(c).apply {
            this.text = text; textSize = sp; setTextColor(0xFF0B0B0F.toInt()); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; includeFontPadding = false
            setPadding(c.dpi(18f), 0, c.dpi(18f), 0)
            val r = c.dpi(heightDp / 2f).toFloat()
            background = pressable(shape(Ui.ACCENT, r), shape(Ui.ACCENT_HI, r))
            isClickable = true; setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(heightDp))
        }

    private fun emptyState(c: Context) {
        val r = c.dpi(22f).toFloat()
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(c.dpi(24f), c.dpi(32f), c.dpi(24f), c.dpi(32f))
            background = shape(Ui.CARD, r, Ui.BORDER, c.dpi(1f))
        }
        card.addView(label(c, if (hasFolder) "No games found" else "No folder yet", 19f, Ui.TEXT, true))
        card.addView(label(c, "Choose the folder with your .gba files. It is scanned automatically every time you open this screen.",
            14f, Ui.MUTED).apply { gravity = Gravity.CENTER }, topMargin(c, 10f))
        card.addView(pillButton(c, "Choose folder", 15f, 46f) { onFolder() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(46f)).apply { topMargin = c.dpi(24f) })
        content.addView(card, topMargin(c, 32f))
    }
}
