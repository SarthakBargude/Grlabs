package com.gbaport.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/** Colours shared by the menu and the home screen (same palette as the GrLabs launcher). */
object Ui {
    val ACCENT = 0xFF7AA2FF.toInt()
    val ACCENT_HI = 0xFF9DB8FF.toInt()
    val CARD = 0xFF14141A.toInt()
    val CARD_HI = 0xFF1D1D26.toInt()
    val BORDER = 0xFF2E2E38.toInt()
    val TEXT = 0xFFF2F2F7.toInt()
    val MUTED = 0xFF9A9AA8.toInt()
    val DANGER = 0xFFFF6B6B.toInt()
    val BADGES = intArrayOf(
        0xFF7AA2FF.toInt(), 0xFF6EE7B7.toInt(), 0xFFF9A8D4.toInt(),
        0xFFFCD34D.toInt(), 0xFFC4B5FD.toInt(), 0xFFFDBA74.toInt())
}

fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun shape(color: Int, radius: Float, strokeColor: Int = 0, strokeWidth: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable = StateListDrawable().apply {
    addState(intArrayOf(android.R.attr.state_pressed), pressed)
    addState(intArrayOf(), normal)
}

fun label(ctx: Context, text: String, sp: Float, color: Int, bold: Boolean = false, spacing: Float = 0f): TextView =
    TextView(ctx).apply {
        this.text = text; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        letterSpacing = spacing
        includeFontPadding = false
    }

fun prettyName(file: String): String = file.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { file }

// =====================================================================================================
// Menu sheet
// =====================================================================================================

const val STYLE_NORMAL = 0
const val STYLE_PRIMARY = 1
const val STYLE_DANGER = 2

class SheetItem(val label: String, val detail: String? = null, val style: Int = STYLE_NORMAL, val onClick: () -> Unit)

/** Dark rounded card with a title and a list of tappable rows. Back / tapping outside calls [onCancel]. */
fun buildSheet(a: Activity, title: String, subtitle: String?, items: List<SheetItem>,
               onPick: (SheetItem) -> Unit, onCancel: () -> Unit): Dialog {
    val d = Dialog(a)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)

    val card = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Ui.CARD, a.dpi(22f).toFloat(), Ui.BORDER, a.dpi(1f))
        setPadding(a.dpi(10f), a.dpi(20f), a.dpi(10f), a.dpi(10f))
    }
    card.addView(label(a, title, 20f, Ui.TEXT, true).apply { setPadding(a.dpi(12f), 0, a.dpi(12f), 0) })
    if (subtitle != null) {
        card.addView(label(a, subtitle, 12.5f, Ui.MUTED).apply {
            setPadding(a.dpi(12f), a.dpi(6f), a.dpi(12f), 0)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
    }

    val list = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, a.dpi(14f), 0, 0)
    }
    for (item in items) list.addView(sheetRow(a, item) { d.dismiss(); onPick(item) })
    val scroll = ScrollView(a).apply { isVerticalScrollBarEnabled = false; addView(list) }
    card.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    d.setContentView(card)
    d.setOnCancelListener { onCancel() }
    d.window?.apply {
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        setDimAmount(0.7f)
        val w = minOf(a.resources.displayMetrics.widthPixels - a.dpi(32f), a.dpi(360f))
        setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    return d
}

fun sheetRow(a: Context, item: SheetItem, click: () -> Unit): View {
    val r = a.dpi(14f).toFloat()
    val primary = item.style == STYLE_PRIMARY
    val textColor = when (item.style) { STYLE_PRIMARY -> 0xFF0B0B0F.toInt(); STYLE_DANGER -> Ui.DANGER; else -> Ui.TEXT }
    val normal = shape(if (primary) Ui.ACCENT else Color.TRANSPARENT, r)
    val pressed = shape(if (primary) Ui.ACCENT_HI else 0x22FFFFFF, r)

    return LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(a.dpi(14f), 0, a.dpi(14f), 0)
        background = pressable(normal, pressed)
        isClickable = true
        setOnClickListener { click() }
        addView(label(a, item.label, 16f, textColor, primary || item.style == STYLE_DANGER),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        item.detail?.let { det ->
            addView(label(a, det, 13f, if (det == "ON") Ui.ACCENT else Ui.MUTED, true))
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dpi(52f)).apply {
            bottomMargin = a.dpi(4f)
        }
    }
}

// =====================================================================================================
// In-game menu page
// =====================================================================================================

/** In-game menu: a full-screen page (same look as the save-state screen) with a close button and a list of rows. */
class MenuView(ctx: Context, private val onClose: () -> Unit) : FrameLayout(ctx) {
    private val header = FrameLayout(ctx)
    private val titleView = TextView(ctx)
    private val subtitleView = TextView(ctx)
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0

    init {
        visibility = GONE
        setBackgroundColor(0xFF08080B.toInt())
        isClickable = true

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(titleView.apply {
            text = "MENU"; textSize = 15f; setTextColor(Color.WHITE)
            typeface = PixelFont.get(ctx); letterSpacing = 0.25f; includeFontPadding = false
        })
        titles.addView(subtitleView.apply {
            textSize = 11f; setTextColor(Ui.MUTED); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false; visibility = GONE
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = ctx.dpi(6f) })
        header.addView(titles, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.START))
        header.addView(closeButton(ctx).apply { setOnClickListener { onClose() } },
            LayoutParams(LayoutParams.WRAP_CONTENT, ctx.dpi(34f), Gravity.CENTER_VERTICAL or Gravity.END))
        col.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(View(ctx).apply { setBackgroundColor(0xFF22222A.toInt()) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))

        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(list) }
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding()
            ins
        }
        applyPadding()
    }

    private var items: List<SheetItem> = emptyList()
    private var builtCols = 0

    private fun applyPadding() {
        val p = context.dpi(18f)
        header.setPadding(p + insL, context.dpi(14f) + insT, p + insR, context.dpi(14f))
        list.setPadding(p + insL, p, p + insR, p + insB)
    }

    /** Landscape: two columns so every entry fits without scrolling. */
    private fun cols() = if (width > height * 1.2f) 2 else 1

    private fun rebuild() {
        val c = context
        builtCols = cols()
        list.removeAllViews()
        if (builtCols == 1) {
            for (item in items) list.addView(sheetRow(c, item) { item.onClick() })
        } else {
            val gap = c.dpi(10f)
            var i = 0
            while (i < items.size) {
                val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                for (j in 0..1) {
                    val lp = LinearLayout.LayoutParams(0, c.dpi(52f), 1f).apply { bottomMargin = c.dpi(4f); if (j == 1) leftMargin = gap }
                    if (i + j < items.size) { val item = items[i + j]; row.addView(sheetRow(c, item) { item.onClick() }, lp) }
                    else row.addView(View(c), lp)
                }
                list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                i += 2
            }
        }
        applyPadding()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (items.isNotEmpty() && cols() != builtCols) rebuild() else applyPadding()
    }

    fun open(subtitle: String?, items: List<SheetItem>) {
        subtitleView.text = subtitle ?: ""
        subtitleView.visibility = if (subtitle.isNullOrEmpty()) GONE else VISIBLE
        this.items = items
        visibility = VISIBLE
        if (width == 0) post { rebuild() } else rebuild()
    }

    fun close() { visibility = GONE }
}

// =====================================================================================================
// Home screen
// =====================================================================================================

/** Icon-only folder button (no box, no border); opens the folder picker. */
class FolderButton(ctx: Context) : View(ctx) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    init { isClickable = true; contentDescription = "Choose folder" }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h) * 0.62f
        val l = (w - s) / 2f; val t = (h - s * 0.8f) / 2f
        val r = l + s; val b = t + s * 0.8f
        val col = if (isPressed) Ui.ACCENT_HI else Ui.ACCENT
        stroke.color = col; stroke.strokeWidth = maxOf(2f, s * 0.085f)
        fillP.color = col
        val tabW = s * 0.38f; val tabH = s * 0.16f; val rad = s * 0.1f
        // folder outline with tab
        path.reset()
        path.moveTo(l + rad, t)
        path.lineTo(l + tabW, t)
        path.lineTo(l + tabW + tabH, t + tabH)
        path.lineTo(r - rad, t + tabH)
        path.quadTo(r, t + tabH, r, t + tabH + rad)
        path.lineTo(r, b - rad)
        path.quadTo(r, b, r - rad, b)
        path.lineTo(l + rad, b)
        path.quadTo(l, b, l, b - rad)
        path.lineTo(l, t + rad)
        path.quadTo(l, t, l + rad, t)
        path.close()
        c.drawPath(path, stroke)
        // small "+" in the middle to hint "add / choose"
        val cx = (l + r) / 2f; val cy = t + tabH + (b - t - tabH) / 2f; val k = s * 0.14f
        c.drawLine(cx - k, cy, cx + k, cy, stroke)
        c.drawLine(cx, cy - k, cx, cy + k, stroke)
    }
}

/** A ROM found in the library folder. [uri] is null for a ROM already copied into app storage. */
class Game(val name: String, val size: Long, val uri: Uri?)

/** Full-screen home: logo + refresh/folder button, then the games as screenshot cards (same look as save states). */
class HomeView(
    ctx: Context,
    private val onPlay: (Game) -> Unit,
    private val onFolder: () -> Unit,
    private val onLong: (Game) -> Unit
) : FrameLayout(ctx) {

    private val content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var insL = 0; private var insT = 0; private var insR = 0; private var insB = 0
    private var games: List<Game> = emptyList()
    private var lastName: String? = null
    private var running = false
    private var scanning = false
    private var hasFolder = false
    private var thumbFor: (String) -> Bitmap? = { null }

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; isFillViewport = true }
        sv.addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(sv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setOnApplyWindowInsetsListener { _, ins ->
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.let { insL = it.safeInsetLeft; insT = it.safeInsetTop; insR = it.safeInsetRight; insB = it.safeInsetBottom }
            }
            applyPadding(); rebuild()
            ins
        }
        applyPadding()
    }

    private fun applyPadding() {
        val p = context.dpi(18f)
        content.setPadding(p + insL, context.dpi(18f) + insT, p + insR, context.dpi(28f) + insB)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        post { rebuild() }
    }

    fun refresh(games: List<Game>, lastName: String?, running: Boolean, scanning: Boolean,
                hasFolder: Boolean, thumbFor: (String) -> Bitmap?) {
        this.games = games; this.lastName = lastName; this.running = running
        this.scanning = scanning; this.hasFolder = hasFolder; this.thumbFor = thumbFor
        rebuild()
    }

    private fun rebuild() {
        val c = context
        content.removeAllViews()

        val header = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(c).apply {
            setImageResource(R.drawable.grlabs_logo); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(22f)))
        header.addView(label(c, "GrLabs", 13f, Color.WHITE, true, 0.14f).apply { setPadding(c.dpi(8f), 0, 0, 0) })
        header.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(FolderButton(c).apply { setOnClickListener { onFolder() } },
            LinearLayout.LayoutParams(c.dpi(44f), c.dpi(44f)))
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (games.isEmpty()) return

        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        content.addView(box, topMargin(c, 24f))
        val avail = width - content.paddingLeft - content.paddingRight
        fillGrid(c, box, avail, games.size) { i, cardW ->
            val g = games[i]
            val playing = running && g.name == lastName
            val caption = prettyName(g.name) + if (playing) "\nPLAYING" else ""
            previewCard(c, thumbFor(g.name), "NO PREVIEW", caption, false, cardW, { onPlay(g) }, { onLong(g) })
        }
    }

    private fun topMargin(c: Context, dp: Float) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = c.dpi(dp) }

    private fun pillButton(c: Context, text: String, sp: Float, heightDp: Float, click: () -> Unit): View =
        TextView(c).apply {
            this.text = text; textSize = sp; setTextColor(0xFF0B0B0F.toInt()); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; includeFontPadding = false
            setPadding(c.dpi(18f), 0, c.dpi(18f), 0)
            val r = c.dpi(heightDp / 2f).toFloat()
            background = pressable(shape(Ui.ACCENT, r), shape(Ui.ACCENT_HI, r))
            isClickable = true; setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, c.dpi(heightDp))
        }
}
