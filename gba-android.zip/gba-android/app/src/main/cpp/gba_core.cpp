// Native GBA core host: mGBA (C library) + EGL/GLES2 video + AAudio sound, driven from one emulation thread.
// All core access happens on that thread; other threads go through runSync().
#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <aaudio/AAudio.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <future>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

extern "C" {
#include <mgba/core/blip_buf.h>
#include <mgba/core/config.h>
#include <mgba/core/core.h>
#include <mgba/core/serialize.h>
#include <mgba/gba/core.h>
#include <mgba/gba/interface.h>
#include <mgba-util/vfs.h>
#include "pk_wide.h"   // map extend (ported from PokeDaisy): the overworld rebuilt past the 240x160 frame
}
#include "wide_camera.h"

#define TAG "GBACore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// If colours come out with red/blue swapped on your build, flip this to 1.
#define SWAP_RB 0

namespace {
using clk = std::chrono::steady_clock;

// ---------- thread plumbing ----------
std::mutex qm;
std::condition_variable qcv;
std::deque<std::function<void()>> q;
std::thread th;
std::atomic<bool> running{false};
std::atomic<uint32_t> keys{0};
std::atomic<int> speed{1};
std::atomic<bool> paused{false};

void post(std::function<void()> f) {
    { std::lock_guard<std::mutex> l(qm); q.push_back(std::move(f)); }
    qcv.notify_one();
}
template <class F> auto runSync(F f) -> decltype(f()) {
    using R = decltype(f());
    std::packaged_task<R()> t(std::move(f));
    auto fut = t.get_future();
    post([&t] { t(); });
    return fut.get();
}

// ---------- core state (emu thread only) ----------
struct mCore* core = nullptr;
std::vector<uint32_t> vbuf;
unsigned vw = 240, vh = 160;
uint64_t frameNo = 0;

// ---------- audio ----------
AAudioStream* astream = nullptr;
int arate = 48000;
clk::time_point nextAudioTry{};
std::vector<int16_t> abuf(4096 * 2);

void audioClose() {
    if (astream) { AAudioStream_requestStop(astream); AAudioStream_close(astream); astream = nullptr; }
}
void audioOpen() {
    if (astream || clk::now() < nextAudioTry) return;
    nextAudioTry = clk::now() + std::chrono::seconds(1);
    AAudioStreamBuilder* b = nullptr;
    if (AAudio_createStreamBuilder(&b) != AAUDIO_OK) return;
    AAudioStreamBuilder_setDirection(b, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setChannelCount(b, 2);
    AAudioStreamBuilder_setSampleRate(b, 48000);
    aaudio_result_t r = AAudioStreamBuilder_openStream(b, &astream);
    AAudioStreamBuilder_delete(b);
    if (r != AAUDIO_OK) { LOGE("AAudio open failed: %s", AAudio_convertResultToText(r)); astream = nullptr; return; }
    arate = AAudioStream_getSampleRate(astream);
    int32_t burst = AAudioStream_getFramesPerBurst(astream);
    AAudioStream_setBufferSizeInFrames(astream, burst * 4);
    AAudioStream_requestStart(astream);
    if (core) {
        blip_set_rates(core->getAudioChannel(core, 0), core->frequency(core), arate);
        blip_set_rates(core->getAudioChannel(core, 1), core->frequency(core), arate);
    }
}
bool audioOk() { return astream != nullptr; }

void pumpAudio(int sp) {
    blip_t* l = core->getAudioChannel(core, 0);
    blip_t* r = core->getAudioChannel(core, 1);
    if (sp != 1) { blip_clear(l); blip_clear(r); return; }
    audioOpen();
    int avail = blip_samples_avail(l);
    if (!astream) { blip_clear(l); blip_clear(r); return; }
    while (avail > 0) {
        int n = std::min<int>(avail, (int)abuf.size() / 2);
        blip_read_samples(l, abuf.data(), n, 1);
        blip_read_samples(r, abuf.data() + 1, n, 1);
        aaudio_result_t w = AAudioStream_write(astream, abuf.data(), n, 50 * 1000 * 1000LL);
        if (w < 0) { LOGE("AAudio write: %s", AAudio_convertResultToText(w)); audioClose(); break; }
        avail -= n;
    }
}

// ---------- video ----------
EGLDisplay dpy = EGL_NO_DISPLAY;
EGLContext ctx = EGL_NO_CONTEXT;
EGLConfig cfg = nullptr;
EGLSurface surf = EGL_NO_SURFACE;
ANativeWindow* win = nullptr;
GLuint prog = 0, tex = 0;
GLint locPos = 0, locUv = 0, locTex = 0;
unsigned texW = 0, texH = 0;

const char* VS = "attribute vec2 p;attribute vec2 t;varying vec2 uv;void main(){uv=t;gl_Position=vec4(p,0.,1.);}";
const char* FS = "precision mediump float;varying vec2 uv;uniform sampler2D s;void main(){vec3 c=texture2D(s,uv).rgb;"
#if SWAP_RB
                 "gl_FragColor=vec4(c.bgr,1.);}";
#else
                 "gl_FragColor=vec4(c,1.);}";
#endif

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    return s;
}
void buildGl() {
    prog = glCreateProgram();
    glAttachShader(prog, compile(GL_VERTEX_SHADER, VS));
    glAttachShader(prog, compile(GL_FRAGMENT_SHADER, FS));
    glLinkProgram(prog);
    locPos = glGetAttribLocation(prog, "p");
    locUv = glGetAttribLocation(prog, "t");
    locTex = glGetUniformLocation(prog, "s");
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    texW = texH = 0;
}
void destroySurface() {
    if (dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (surf != EGL_NO_SURFACE) eglDestroySurface(dpy, surf);
    }
    surf = EGL_NO_SURFACE;
}
void setWindow(ANativeWindow* w) {
    destroySurface();
    if (win) { ANativeWindow_release(win); win = nullptr; }
    win = w;
    if (!win) return;
    if (dpy == EGL_NO_DISPLAY) {
        dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglInitialize(dpy, nullptr, nullptr);
        const EGLint ca[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                             EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_NONE};
        EGLint n = 0;
        eglChooseConfig(dpy, ca, &cfg, 1, &n);
        const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE};
        ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    }
    surf = eglCreateWindowSurface(dpy, cfg, win, nullptr);
    if (surf == EGL_NO_SURFACE || !eglMakeCurrent(dpy, surf, surf, ctx)) { LOGE("EGL surface failed"); destroySurface(); return; }
    eglSwapInterval(dpy, 0);  // pacing comes from audio / our own limiter, not vsync
    if (!prog) buildGl();
}
// Uploads w x h pixels and draws them into the screen-pixel rectangle [x0,x1] x [y0,y1] of the surface.
// texAllocW/H: the texture's size (the wide path keeps one fixed 800x800 texture so a zoom animation, whose window
// changes size every frame, never reallocates it); only the top-left w x h of it is shown.
void present(const uint32_t* pixels, unsigned w, unsigned h, unsigned texAllocW, unsigned texAllocH,
             float x0, float y0, float x1, float y1, EGLint sw, EGLint sh) {
    glBindTexture(GL_TEXTURE_2D, tex);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    if (texAllocW != texW || texAllocH != texH) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texAllocW, texAllocH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        texW = texAllocW; texH = texAllocH;
    }
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, pixels);

    const float u1 = (float)w / texAllocW, v1 = (float)h / texAllocH;
    const float l = x0 / sw * 2.f - 1.f, r = x1 / sw * 2.f - 1.f;
    const float t = 1.f - y0 / sh * 2.f, b = 1.f - y1 / sh * 2.f;
    glViewport(0, 0, sw, sh);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    const GLfloat v[] = {l, b, 0.f, v1,  r, b, u1, v1,  l, t, 0.f, 0.f,  r, t, u1, 0.f};
    glUseProgram(prog);
    glUniform1i(locTex, 0);
    glEnableVertexAttribArray(locPos);
    glEnableVertexAttribArray(locUv);
    glVertexAttribPointer(locPos, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), v);
    glVertexAttribPointer(locUv, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), v + 2);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    if (!eglSwapBuffers(dpy, surf)) {
        EGLint e = eglGetError();
        if (e == EGL_BAD_SURFACE || e == EGL_BAD_NATIVE_WINDOW) destroySurface();
    }
}

bool surfaceSize(EGLint& sw, EGLint& sh) {
    sw = sh = 0;
    if (surf == EGL_NO_SURFACE) return false;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &sw);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &sh);
    return sw > 0 && sh > 0;
}

// The plain frame, aspect-correct fit inside the surface.
void render(const uint32_t* pixels, unsigned w, unsigned h) {
    EGLint sw, sh;
    if (!pixels || !surfaceSize(sw, sh)) return;
    float s = std::min((float)sw / w, (float)sh / h);
    float fw = w * s, fh = h * s;
    float x0 = (sw - fw) / 2.f, y0 = (sh - fh) / 2.f;
    present(pixels, w, h, w, h, x0, y0, x0 + fw, y0 + fh, sw, sh);
}

// ---------- map extend (pk_wide.c) + zoom (WideCamera) ----------
// For a Pokémon Gen 3 game pk_wide.c knows (by ROM CRC32), the strips around the game's own frame are rebuilt from the
// game's memory, and WideCamera picks the window of that scene to show: zoomed out, panned, or pulled in to 1x.
// Any other game is drawn plain, exactly as before.
WideCamera cam;
std::vector<uint32_t> wbuf;                    // pk_wide_view's output, PK_WIDE_MAX_VIEW_W x _H
uint32_t wideCrc = 0;                          // the loaded ROM's CRC32 if pk_wide knows it, else 0 (emu thread)
std::atomic<bool> wideKnown{false};            // wideCrc != 0, for the UI thread
std::atomic<bool> extendOn{true};              // the "Extend map" setting
int lastScene = PK_WIDE_SCENE_OFF;

// The strips are drawn for the GBA's 240x160 frame in 32-bit colour (mGBA's default, which vbuf already assumes).
bool wideActive() { return extendOn && wideCrc && vw == 240 && vh == 160 && sizeof(color_t) == 4; }

void wideReset() {
    pk_wide_reset();
    cam.reset();
    lastScene = PK_WIDE_SCENE_OFF;
}

int64_t nowNanos() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(clk::now().time_since_epoch()).count();
}

// A frame that is shown: the scene rebuilt for the camera's window and drawn at its zoom.
void drawWide() {
    EGLint sw, sh;
    WideWindow win;
    if (surfaceSize(sw, sh)) { cam.viewW = sw; cam.viewH = sh; }   // never zeroed by a surface that is momentarily gone
    if (!cam.viewW || !cam.frame(lastScene, nowNanos(), win)) {
        pk_wide_skip(core, vbuf.data());          // nothing to show now: only keep the game's RAM history
        return;
    }
    if (wbuf.empty()) wbuf.assign((size_t)PK_WIDE_MAX_VIEW_W * PK_WIDE_MAX_VIEW_H, 0);
    struct PkWideView v = {win.x, win.y, win.w, win.h};
    pk_wide_view(core, vbuf.data(), wbuf.data(), v, nullptr);
    lastScene = pk_wide_scene();
    if (pk_wide_fault()) {
        // It faulted while drawing and switched itself off: this game shows the plain frame from now on.
        LOGE("map extend switched off: signal %d while drawing", pk_wide_fault());
        wideCrc = 0; wideKnown = false;
        render(vbuf.data(), vw, vh);
        return;
    }
    present(wbuf.data(), win.w, win.h, PK_WIDE_MAX_VIEW_W, PK_WIDE_MAX_VIEW_H,
            win.offX, win.offY, win.offX + win.w * win.scale, win.offY + win.h * win.scale, sw, sh);
}

// ---------- core lifecycle (emu thread) ----------
void unloadCore() {
    if (!core) return;
    pk_wide_configure(0);
    pk_wide_extras_reset();
    wideCrc = 0; wideKnown = false;
    mCoreConfigDeinit(&core->config);
    core->deinit(core);
    core = nullptr;
}
bool loadRom(const std::string& path) {
    unloadCore();
    struct mCore* c = GBACoreCreate();
    if (!c) return false;
    if (!c->init(c)) return false;
    mCoreInitConfig(c, nullptr);
    struct mCoreOptions opts = {};
    opts.useBios = false;  // built-in HLE BIOS
    opts.volume = 0x100;
    opts.mute = false;
    opts.audioBuffers = 1024;
    mCoreConfigLoadDefaults(&c->config, &opts);
    mCoreLoadConfig(c);

    c->desiredVideoDimensions(c, &vw, &vh);
    vbuf.assign((size_t)vw * vh, 0);
    c->setVideoBuffer(c, vbuf.data(), vw);
    c->setAudioBufferSize(c, 2048);
    if (!mCoreLoadFile(c, path.c_str())) {
        LOGE("mCoreLoadFile failed: %s", path.c_str());
        mCoreConfigDeinit(&c->config);
        c->deinit(c);
        return false;
    }
    mCoreAutoloadSave(c);  // <rom>.sav next to the ROM, battery-backed
    c->reset(c);
    core = c;
    audioOpen();
    blip_set_rates(c->getAudioChannel(c, 0), c->frequency(c), arate);
    blip_set_rates(c->getAudioChannel(c, 1), c->frequency(c), arate);
    frameNo = 0;
    uint32_t crc = 0;
    c->checksum(c, &crc, mCHECKSUM_CRC32);
    wideCrc = pk_wide_configure(crc) ? crc : 0;
    wideKnown = wideCrc != 0;
    wideReset();
    LOGI("ROM loaded (%ux%u) crc %08x%s: %s", vw, vh, crc, wideCrc ? " (map extend)" : "", path.c_str());
    return true;
}

void loop() {
    auto next = clk::now();
    while (running) {
        for (;;) {
            std::function<void()> fn;
            { std::lock_guard<std::mutex> l(qm); if (q.empty()) break; fn = std::move(q.front()); q.pop_front(); }
            fn();
            next = clk::now();
        }
        if (!core || paused) {
            std::unique_lock<std::mutex> lk(qm);
            qcv.wait_for(lk, std::chrono::milliseconds(20), [] { return !q.empty() || !running; });
            next = clk::now();
            continue;
        }
        const uint32_t k = keys.load();
        cam.walking = (k & 0xF0u) != 0;   // RIGHT, LEFT, UP, DOWN held: the player is walking
        core->setKeys(core, k);
        core->runFrame(core);
        int sp = std::max(1, speed.load());
        pumpAudio(sp);
        const bool show = frameNo++ % sp == 0;
        if (wideActive()) {
            if (show) drawWide(); else pk_wide_skip(core, vbuf.data());   // fast-forward: only note the frame
        } else if (show) {
            render(vbuf.data(), vw, vh);
        }
        if (sp == 1 && audioOk()) {
            next = clk::now();  // blocking audio writes are the clock
        } else {
            next += std::chrono::microseconds(16743 / sp);
            auto now = clk::now();
            if (next < now) next = now; else std::this_thread::sleep_until(next);
        }
    }
    unloadCore();
    setWindow(nullptr);
    audioClose();
}
}  // namespace

// ================= JNI =================
#define JNI(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_gbaport_app_NativeCore_##name

JNI(void, nativeInit)(JNIEnv*, jobject) {
    if (running.exchange(true)) return;
    th = std::thread(loop);
}
JNI(void, nativeShutdown)(JNIEnv*, jobject) {
    if (!running.exchange(false)) return;
    qcv.notify_all();
    if (th.joinable()) th.join();
}
JNI(void, nativeSurfaceCreated)(JNIEnv* env, jobject, jobject surface) {
    ANativeWindow* w = ANativeWindow_fromSurface(env, surface);
    post([w] { setWindow(w); });
}
JNI(void, nativeSurfaceDestroyed)(JNIEnv*, jobject) {
    runSync([] { setWindow(nullptr); return 0; });
}
JNI(jboolean, nativeLoadRom)(JNIEnv* env, jobject, jstring jpath) {
    const char* p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p);
    env->ReleaseStringUTFChars(jpath, p);
    return runSync([path] { return loadRom(path); }) ? JNI_TRUE : JNI_FALSE;
}
JNI(void, nativeSetKeys)(JNIEnv*, jobject, jint mask) { keys = (uint32_t)mask & 0x3FFu; }
JNI(void, nativeSetSpeed)(JNIEnv*, jobject, jint s) { speed = std::max(1, std::min<int>(s, 8)); }
JNI(void, nativeSetPaused)(JNIEnv*, jobject, jboolean p) {
    paused = p;
    runSync([p] {
        if (astream) { if (p) AAudioStream_requestPause(astream); else { AAudioStream_requestFlush(astream); AAudioStream_requestStart(astream); } }
        return 0;
    });
}
JNI(jbyteArray, nativeGetState)(JNIEnv* env, jobject) {
    std::vector<uint8_t> out = runSync([] {
        std::vector<uint8_t> o;
        if (!core) return o;
        VFile* vf = VFileMemChunk(nullptr, 0);
        if (mCoreSaveStateNamed(core, vf, SAVESTATE_SAVEDATA | SAVESTATE_RTC)) {
            size_t n = vf->size(vf);
            o.resize(n);
            vf->seek(vf, 0, SEEK_SET);
            vf->read(vf, o.data(), n);
        }
        vf->close(vf);
        return o;
    });
    if (out.empty()) return nullptr;
    jbyteArray arr = env->NewByteArray((jsize)out.size());
    env->SetByteArrayRegion(arr, 0, (jsize)out.size(), reinterpret_cast<const jbyte*>(out.data()));
    return arr;
}
JNI(jboolean, nativeLoadState)(JNIEnv* env, jobject, jbyteArray data) {
    jsize n = env->GetArrayLength(data);
    std::vector<uint8_t> in(n);
    env->GetByteArrayRegion(data, 0, n, reinterpret_cast<jbyte*>(in.data()));
    bool ok = runSync([&in] {
        if (!core) return false;
        VFile* vf = VFileMemChunk(in.data(), in.size());
        vf->seek(vf, 0, SEEK_SET);
        bool r = mCoreLoadStateNamed(core, vf, SAVESTATE_SAVEDATA | SAVESTATE_RTC);
        vf->close(vf);
        wideReset();   // the RAM the extend kept from the last frame belongs to another moment
        return r;
    });
    return ok ? JNI_TRUE : JNI_FALSE;
}

// Current video frame as ARGB ints (240x160), used for save-state thumbnails.
JNI(jintArray, nativeGetFrame)(JNIEnv* env, jobject) {
    std::vector<jint> out = runSync([] {
        std::vector<jint> o;
        if (!core || vbuf.empty()) return o;
        o.resize(vbuf.size());
        for (size_t i = 0; i < vbuf.size(); i++) {
            uint32_t p = vbuf[i];  // memory order R,G,B,A
#if SWAP_RB
            o[i] = (jint)(0xFF000000u | (p & 0xFF00u) | ((p & 0xFFu) << 0) | (p & 0xFF0000u));
#else
            o[i] = (jint)(0xFF000000u | ((p & 0xFFu) << 16) | (p & 0xFF00u) | ((p >> 16) & 0xFFu));
#endif
        }
        return o;
    });
    if (out.empty()) return nullptr;
    jintArray arr = env->NewIntArray((jsize)out.size());
    env->SetIntArrayRegion(arr, 0, (jsize)out.size(), out.data());
    return arr;
}

// ---------- map extend / zoom ----------
// Whether the loaded game is one the map extend knows (a Pokémon Gen 3 release by ROM CRC32).
JNI(jboolean, nativeWideKnown)(JNIEnv*, jobject) { return wideKnown.load() ? JNI_TRUE : JNI_FALSE; }

// The "Extend map" setting. Off draws the plain frame, as before.
JNI(void, nativeSetExtend)(JNIEnv*, jobject, jboolean on) {
    extendOn = on == JNI_TRUE;
    post([] { wideReset(); });
}

// The game view's size in screen pixels (the surface's), so the zoom steps are known before the first frame.
JNI(void, nativeSetViewSize)(JNIEnv*, jobject, jint w, jint h) { cam.viewW = w; cam.viewH = h; }

// Zoom: step 0 is 1x, each following one shows more of the map. All return the step now in force.
JNI(jint, nativeZoomCycle)(JNIEnv*, jobject) { return cam.cycle(); }
JNI(jint, nativeZoomStep)(JNIEnv*, jobject, jint dir) { return cam.step(dir); }
JNI(void, nativeSetZoom)(JNIEnv*, jobject, jint level) { cam.level = std::max(0, level); }
JNI(jint, nativeGetZoom)(JNIEnv*, jobject) {
    return std::min<int>(std::max(0, cam.level.load()), (int)cam.levels().size() - 1);
}
// How much more of the map each step shows than 1x (1.0, 1.46, 2.2 ...).
JNI(jfloatArray, nativeZoomFactors)(JNIEnv* env, jobject) {
    std::vector<float> f = cam.factors();
    jfloatArray arr = env->NewFloatArray((jsize)f.size());
    env->SetFloatArrayRegion(arr, 0, (jsize)f.size(), f.data());
    return arr;
}

// Look-around: the right stick, -1..1 per axis (right / down positive).
JNI(void, nativeSetLook)(JNIEnv*, jobject, jfloat x, jfloat y) { cam.stickX = x; cam.stickY = y; }
