// Zoom and look-around over the extended map (pk_wide.c): which window of the scene is drawn each frame.
//
// A C++ port of PokeDaisy's WideCamera.kt (GPL-3.0-or-later, https://github.com/lidor30/pokedaisy), GBA only.
// The camera runs on the emulation thread; other threads only touch the atomic inputs.
//
//  * Zoom steps: level 0 is the game as large as the view shows all of it (1x); each step out is a whole number
//    of screen pixels per GBA pixel, so the pixel art stays crisp, and only steps that show at least 1.2x more
//    map than the one before are offered (and only inside pk_wide's largest window, 800 x 800 GBA pixels).
//  * Close up when it matters: battles, menu screens and text boxes pull the view in to 1x, then ease back out
//    to the chosen step half a second after the game is back on the map.
//  * Look-around (right stick): standing still it moves the view, which stays where it is left; walking glides
//    it back to the player (or follows the stick, always keeping the player on screen).
#pragma once

#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

struct WideWindow {
    int x = 0, y = 0, w = 0, h = 0;      // the window in GBA pixels, (0,0) = the game frame's top-left corner
    float offX = 0, offY = 0;            // where it sits on the view, in screen pixels from its top-left (<= 0)
    float scale = 1;                     // screen pixels per GBA pixel
};

class WideCamera {
public:
    // pk_wide.h's PK_WIDE_SCENE_*
    enum { SCENE_FIELD = 0, SCENE_TEXT = 1, SCENE_OVERLAY = 2, SCENE_BATTLE_START = 3, SCENE_OFF = 4,
           SCENE_FADE = 5, SCENE_MENU = 6 };
    static constexpr int FRAME_W = 240, FRAME_H = 160;     // the GBA's frame
    static constexpr int MAX_W = 800, MAX_H = 800;         // PK_WIDE_MAX_VIEW_W / _H

    // ---- inputs (any thread)
    std::atomic<int> viewW{0}, viewH{0};                   // the game view's size in screen pixels
    std::atomic<int> level{0};                             // the zoom step picked: 0 = 1x
    std::atomic<float> stickX{0.f}, stickY{0.f};           // right stick, -1..1 (right / down positive)
    std::atomic<bool> walking{false};                      // a direction is held
    std::atomic<bool> zoomOnText{true};                    // a text box pulls in to 1x
    std::atomic<bool> lookAround{true};                    // the right stick moves the view

    /** Screen pixels per GBA pixel for each zoom step, 1x first. */
    static std::vector<float> levelsFor(int w, int h) {
        if (w <= 0 || h <= 0) return {1.f};
        const float fit = std::min(w / (float) FRAME_W, h / (float) FRAME_H);
        std::vector<float> out{fit};
        int k = (int) std::floor(fit);
        if ((float) k == fit) k--;
        while (k >= 1) {
            if (w / (float) k > MAX_W || h / (float) k > MAX_H) break;
            if (out.back() / k >= MIN_STEP) out.push_back((float) k);
            k--;
        }
        return out;
    }
    std::vector<float> levels() const { return levelsFor(viewW.load(), viewH.load()); }

    /** How much more of the map each step shows than 1x ("1.5"), for the button. */
    std::vector<float> factors() const {
        std::vector<float> l = levels();
        for (float& f : l) f = l[0] / f;
        return l;
    }

    /** The next step out, back to 1x after the last. Returns the new step. */
    int cycle() {
        const int n = (int) levels().size();
        const int next = n <= 1 ? 0 : (std::clamp(level.load(), 0, n - 1) + 1) % n;
        level = next;
        return next;
    }

    /** One step out (dir > 0) or in (dir < 0), stopping at the ends. Returns the new step. */
    int step(int dir) {
        const int n = (int) levels().size();
        const int next = std::clamp(level.load() + (dir > 0 ? 1 : dir < 0 ? -1 : 0), 0, std::max(0, n - 1));
        level = next;
        return next;
    }

    /** Back to 1x on the player at once (a new game, a state load, the map switched on); the step picked comes back
     * half a second after the field shows. Emu thread. */
    void reset() {
        closeOverSince = 0;
        scale = 0.f;
        lookX = lookY = 0.f;
        lastNanos = 0;
        tweenTarget = 0.f;
    }

    /** Emu thread, once per frame: the window to draw, given what the last frame was (SCENE_*).
     * False without a view yet. */
    bool frame(int scene, int64_t now, WideWindow& out) {
        const int vw = viewW.load(), vh = viewH.load();
        if (vw <= 0 || vh <= 0) return false;
        const std::vector<float> steps = levelsFor(vw, vh);
        const float fit = steps[0];
        const float dt = lastNanos == 0 ? 0.f : std::clamp((now - lastNanos) / 1e9f, 0.f, 0.1f);
        lastNanos = now;

        const bool wantsClose = scene == SCENE_FIELD ? false : scene == SCENE_TEXT ? zoomOnText.load() : true;
        // A fade decides nothing, nor does a picture over the field (FireRed's map preview).
        if (scene == SCENE_FADE || scene == SCENE_OVERLAY) { /* hold */ }
        else if (wantsClose) closeOverSince = 0;
        else if (closeOverSince == 0) closeOverSince = now;
        const bool close = closeOverSince == 0 || now - closeOverSince < RETURN_DELAY_NANOS;
        const int lv = std::clamp(level.load(), 0, (int) steps.size() - 1);
        const float target = close ? fit : steps[lv];

        // The zoom is a timed ease-in-out in log space: a new target starts a new motion from wherever the last is.
        if (target != tweenTarget) {
            tweenFrom = scale <= 0.f ? target : scale;
            tweenTarget = target;
            tweenStart = now;
            tweenNanos = scale <= 0.f ? 0
                       : target > tweenFrom && scene == SCENE_BATTLE_START ? PULL_IN_BATTLE_NANOS
                       : target > tweenFrom ? PULL_IN_NANOS : ZOOM_OUT_NANOS;
        }
        const float p = tweenNanos <= 0 ? 1.f : std::clamp((now - tweenStart) / (float) tweenNanos, 0.f, 1.f);
        scale = tweenFrom * std::pow(tweenTarget / tweenFrom, smoothstep(p));
        if (std::fabs(scale - target) < 0.002f) scale = target;

        const float fw = vw / scale, fh = vh / scale;
        const bool look = lookAround.load();
        const float sx = look ? deadZone(stickX.load()) : 0.f;
        const float sy = look ? deadZone(stickY.load()) : 0.f;
        const bool stick = sx != 0.f || sy != 0.f;
        if (close) {
            spring(0.f, 0.f, dt, LOOK_TAU);
        } else if (walking.load() && stick) {
            // Follow the stick, the player kept on screen: the view's centre at most this far off them.
            const float maxX = std::max(0.f, fw / 2 - PLAYER_KEEP), maxY = std::max(0.f, fh / 2 - PLAYER_KEEP);
            spring(sx * maxX, sy * maxY, dt, LOOK_TAU);
        } else if (walking.load()) {
            spring(0.f, 0.f, dt, RETURN_TAU);
        } else if (stick) {
            const float speed = LOOK_SPEED * std::max(1.f, fit / scale);   // further out, the view travels faster
            lookX += sx * speed * dt;
            lookY += sy * speed * dt;
        }
        // As far as a screen's worth of map past the game's own view each way.
        const float limX = std::max(fw, (float) FRAME_W), limY = std::max(fh, (float) FRAME_H);
        lookX = std::clamp(lookX, -limX, limX);
        lookY = std::clamp(lookY, -limY, limY);

        const float fx = FRAME_W / 2.f + lookX - fw / 2, fy = FRAME_H / 2.f + lookY - fh / 2;
        const int x = (int) std::floor(fx), y = (int) std::floor(fy);
        out.x = x;
        out.y = y;
        out.w = std::min(MAX_W, (int) std::ceil(fx + fw) - x);
        out.h = std::min(MAX_H, (int) std::ceil(fy + fh) - y);
        out.offX = (x - fx) * scale;
        out.offY = (y - fy) * scale;
        out.scale = scale;
        return out.w > 0 && out.h > 0;
    }

private:
    static constexpr float MIN_STEP = 1.2f;                       // a step out shows at least this much more
    static constexpr int64_t PULL_IN_NANOS = 420'000'000;         // to 1x for a text box or a menu
    static constexpr int64_t PULL_IN_BATTLE_NANOS = 550'000'000;  // over a battle's first flashes
    static constexpr int64_t ZOOM_OUT_NANOS = 650'000'000;        // the way back out, slower
    static constexpr int64_t RETURN_DELAY_NANOS = 500'000'000;    // the close view is over this long before zooming out
    static constexpr float LOOK_TAU = 0.12f;                      // s: following the stick / a close-up
    static constexpr float RETURN_TAU = 0.18f;                    // s: gliding back to a player who starts walking
    static constexpr float LOOK_SPEED = 150.f;                    // GBA px per s at full stick, at 1x
    static constexpr float PLAYER_KEEP = 28.f;                    // GBA px: the player's sprite stays this far inside
    static constexpr float DEAD_ZONE = 0.2f;

    float scale = 0.f, lookX = 0.f, lookY = 0.f;
    int64_t lastNanos = 0;
    int64_t closeOverSince = 0;   // when the game last stopped wanting a close view (0 = it still does)
    float tweenFrom = 0.f, tweenTarget = 0.f;
    int64_t tweenStart = 0, tweenNanos = 0;

    void spring(float tx, float ty, float dt, float tau) {
        const float k = 1.f - std::exp(-dt / tau);
        lookX += (tx - lookX) * k;
        lookY += (ty - lookY) * k;
        if (std::hypot(lookX - tx, lookY - ty) < 0.05f) { lookX = tx; lookY = ty; }
    }
    static float smoothstep(float p) { return p * p * (3.f - 2.f * p); }
    static float deadZone(float v) {
        const float a = std::fabs(v);
        if (a < DEAD_ZONE) return 0.f;
        return (a - DEAD_ZONE) / (1.f - DEAD_ZONE) * (v < 0 ? -1.f : 1.f);
    }
};
