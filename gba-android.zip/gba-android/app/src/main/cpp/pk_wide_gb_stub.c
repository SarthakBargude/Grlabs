// GBA-only build: pokedaisy's Game Boy / Game Boy Color map extension (pk_wide_gb.c) is not included,
// so every Game Boy entry point pk_wide.c can reach says "not a game I know" and draws nothing.
// GPL-3.0-or-later, part of the map-extend port from PokeDaisy (https://github.com/lidor30/pokedaisy).
#include "pk_wide.h"
#include "pk_wide_gb_profile.h"

int pk_wide_gb_knows(uint32_t crc) { (void) crc; return 0; }
int pk_wide_gb_configure(uint32_t crc) { (void) crc; return 0; }
void pk_wide_gb_reset(void) {}
int pk_wide_gb_view(struct mCore* core, const uint32_t* frame, uint32_t* out, struct PkWideView view, uint32_t* centre) {
    (void) core; (void) frame; (void) out; (void) view; (void) centre;
    return 0;
}
int pk_wide_gb_glow(struct mCore* core, const uint32_t* frame, uint32_t* out, struct PkWideView view) {
    (void) core; (void) frame; (void) out; (void) view;
    return 0;
}
int pk_wide_gb_scene(void) { return PK_WIDE_SCENE_OFF; }
int pk_wide_gb_wants_close(void) { return 1; }
int pk_wide_gb_last_mode(void) { return PK_WIDE_MODE_NONE; }
int pk_wide_gb_last_score(void) { return -1; }
int pk_wide_gb_last_torn(void) { return 0; }
int pk_wide_gb_configure_polished(const uint32_t addresses[GB_CONFIG], pk_wide_gb_decode_fn decode) {
    (void) addresses; (void) decode;
    return 0;
}
