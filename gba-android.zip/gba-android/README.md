# GBA – native Android

mGBA (C) core hosted in C++ (`app/src/main/cpp/gba_core.cpp`: emulation thread, GLES2 video, AAudio sound, save states) with a plain Kotlin UI (on-screen pad, gamepad support, menu). No WebView, no HTML, no network permission.

Controls and game placement copy the GrLabs HTML launcher (same positions, colors, and D-pad press animation; header with GrLabs logo, » fast-forward and ☰ menu). Opens on a **home screen**: pick your ROM folder once (Choose folder) and every .gba/.agb inside it (sub-folders too) is scanned and shown as screenshot cards, same look as the save-state screen. Tap a card to play; long-press clears that game's saves. The ☰ button (or Back / the MENU key) slides a **drawer in from the right**: Resume · Quick save · Quick load · Save state · Load state · Fast-forward ×4 · Reset · Home. Save state / Load state open a grid of screenshot slots (Load also lists the quick save, which is written automatically when you leave a game). Battery saves (`.sav`) are automatic.

## Build
- **GitHub:** push the folder; Actions → "Build APK" → download the `gba-emulator-debug-apk` artifact (arm64).
- **Local:** open in Android Studio (NDK 26.1 + CMake 3.22.1) and run, or `gradle assembleDebug`.

## If the first build complains
- mGBA tag not found → change `MGBA_TAG` in `cpp/CMakeLists.txt`.
- `libmgba.a` missing → find its real name under `app/.cxx/**/mgba/src/mgba_ext-build/`, update `BUILD_BYPRODUCTS` / `IMPORTED_LOCATION`.
- Red/blue swapped → `SWAP_RB 1` in `gba_core.cpp`.

## Optional pixel font
Drop a pixel TTF (e.g. Silkscreen, OFL) at `app/src/main/assets/fonts/pixel.ttf` for the pixel look on the Save States screen; without it a bold monospace is used.


## HTML-matched control refinements
- D-pad uses the HTML launcher's directional 2px nudge and quick brightness response, without shifting the whole socket.
- Portrait D-pad is raised slightly from the bottom; A/B sit farther from the right edge with a wider diagonal separation.
- Display border is thin and understated like the HTML display frame.
- Fast-forward stays a direct tap toggle (no menu popup) and uses a pixel-stepped double-chevron icon. The Android activity already runs immersive full-screen with system bars hidden.


## Map extend + zoom (Pokémon Gen 3)
Based on PokeDaisy by Lidor Itzhari - https://github.com/lidor30/pokedaisy (GPL-3.0, see NOTICE).

For Pokémon FireRed / LeafGreen / Emerald / Ruby / Sapphire (every language and revision) and the ROM hacks PokeDaisy lists, the overworld is rebuilt every frame from the game's own memory past the 240x160 edges, and you can zoom out to see more map. The ROM is recognised by its CRC32 (`pk_wide_games.h`); any other game plays as before and shows no zoom button.
- **Header buttons** (portrait and landscape), left to right: quick save, quick load, zoom (landscape, supported games only), fast-forward, menu. Zoom steps 1x → more map → back to 1x.
- **Gamepad:** R3 = next zoom step, right stick = look around.
- L, R, SELECT and START respond to a tap only (a finger sliding onto them does nothing); D-pad and A/B still slide.
- ☰ menu: **Extend map** ON/OFF and **Zoom** (supported games only).
- Needs mGBA 0.10.x (`MGBA_TAG`); it reads mGBA's internal structs.


## Party sidebar + Start/Select gap
- **Party bar**: for every Gen 3 Pokémon game the map extend knows (FireRed/LeafGreen, Ruby/Sapphire/Emerald and the hacks in `pk_wide_games.h`) a sidebar shows all 6 party slots: ball icon, name, level, HP bar (green/yellow/red) with HP numbers, and a status tag (SLP/PSN/BRN/FRZ/PAR). Fainted slots grey out, eggs show an egg, empty slots are dim. Landscape: a column on the left (the game picture and the controls shift right). Portrait: a row under the display when the screen has room. ☰ menu → **Party bar** turns it on/off.
- The party is read from SaveBlock1 in RAM by `pk_party_read` (pk_wide.c) every 20 frames; hacks with a moved SaveBlock1 (`PK_WIDE_SB1_POS`) or an unexpected layout simply show no bar.
- **SELECT / START** are 5 cm apart (measured with the screen's real dpi), clamped so both keys stay on screen/inside the deck on narrow phones.

- **L / R buttons** and **Select / Start** each have an ON/OFF row in the ☰ menu; OFF hides the keys on screen (and they cannot be pressed). Remembered between launches. Gamepad buttons still work.

- **Party sidebar reads the live party** (the game's own gPlayerParty array, found by record checksum), not SaveBlock1's copy, which only updates on save. Icons are the game's own front sprites read from the ROM (`pk_mon_sprite`), so they work offline and match hacks; the PokeAPI download is only a fallback.
