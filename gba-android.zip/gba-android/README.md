# GBA – native Android

mGBA (C) core hosted in C++ (`app/src/main/cpp/gba_core.cpp`: emulation thread, GLES2 video, AAudio sound, save states) with a plain Kotlin UI (on-screen pad, gamepad support, menu). No WebView, no HTML, no network permission.

Controls and game placement copy the GrLabs HTML launcher (same positions, colors, and D-pad press animation; header with GrLabs logo, » fast-forward and ☰ menu). Opens on a **home screen**: pick your ROM folder once (Choose folder) and every .gba/.agb inside it (sub-folders too) is scanned and shown as screenshot cards, same look as the save-state screen. Tap a card to play; long-press clears that game's saves. The ☰ button (or Back / the MENU key) slides a **drawer in from the right**: Resume · Quick save · Quick load · Save state · Load state · Fast-forward ×4 · Reset · Home. Save state / Load state open a grid of screenshot slots (Load also lists the quick save, which is written automatically when you leave a game). Battery saves (`.sav`) are automatic.

## Build
- **GitHub:** push the folder; Actions → "Build APK" → download the `gba-emulator-debug-apk` artifact (arm64).
- **Local:** open in Android Studio (NDK 26.1 + CMake 3.22.1) and run, or `gradle assembleDebug`.

## If the first build complains
- mGBA tag not found → change `MGBA_TAG` in `cpp/CMakeLists.txt`.
- `libmgba.a` missing → find its real name under `app/.cxx/**/mgba/src/mgba_ext-build/`, update `BUILD_BYPRODUCTS` / `IMPORTED_LOCATION`.
- Red/blue swapped → `SWAP_RB 1` in `gba_core.cpp`.

## Optional pixel font
Drop a pixel TTF (e.g. Silkscreen, OFL) at `app/src/main/assets/fonts/pixel.ttf` for the pixel look on the Save States screen; without it a bold monospace is used.


## HTML-matched control refinements
- D-pad uses the HTML launcher's directional 2px nudge and quick brightness response, without shifting the whole socket.
- Portrait D-pad is raised slightly from the bottom; A/B sit farther from the right edge with a wider diagonal separation.
- Display border is thin and understated like the HTML display frame.
- Fast-forward stays a direct tap toggle (no menu popup) and uses a pixel-stepped double-chevron icon. The Android activity already runs immersive full-screen with system bars hidden.
